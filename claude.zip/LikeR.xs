/* --- C HELPER SECTION --- */
#define PERL_NO_GET_CONTEXT
#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"
#include "ppport.h"
#include <math.h>
#include <ctype.h>
#include <stdlib.h>
#include <float.h>
#include <string.h>
/* Ensure Perl's PRNG is seeded, matching the lazy-evaluation of Perl's rand() */
#define AUTO_SEED_PRNG() \
    do { \
        if (!PL_srand_called) { \
            (void)seedDrand01((Rand_seed_t)Perl_seed(aTHX)); \
            PL_srand_called = TRUE; \
        } \
    } while (0)

// ---------------------------------------
//   Helpers for Random Number Generation
// ---------------------------------------
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
// --- Math Helpers for P-values and Confidence Intervals --- 

// Inverse Normal CDF (Approximate) for Confidence Intervals
static double qnorm(double p) {
    double a[] = { 2.50662823884, -18.61500062529, 41.39119773534, -25.44106049637 };
    double b[] = { -8.47351093090, 23.08336743743, -21.06224101826, 3.13082909833 };
    double c[] = { 0.33747562770, 0.97616901909, 0.16079797149, 0.02764368149, 0.00384057293, 0.00039518965, 0.00003217679, 0.00000028881, 0.00000000396 };
    double r, x;
    double y = p - 0.5;
    if (fabs(y) < 0.42) {
        r = y * y;
        x = y * (((a[3]*r + a[2])*r + a[1])*r + a[0]) / ((((b[3]*r + b[2])*r + b[1])*r + b[0])*r + 1.0);
    } else {
        r = p;
        if (y > 0) r = 1.0 - p;
        r = log(-log(r));
        x = c[0] + r * (c[1] + r * (c[2] + r * (c[3] + r * (c[4] + r * (c[5] + r * (c[6] + r * (c[7] + r * c[8])))))));
        if (y < 0) x = -x;
    }
    return x;
}

// Rank helper for Spearman
typedef struct { double val; int index; double rank; } RankItem_cor_test;
static int compare_rank(const void *restrict a, const void *restrict b) {
    double diff = ((RankItem_cor_test*)a)->val - ((RankItem_cor_test*)b)->val;
    return (diff > 0) - (diff < 0);
}

static int compare_index(const void *restrict a, const void *restrict b) {
    return ((RankItem_cor_test*)a)->index - ((RankItem_cor_test*)b)->index;
}

static void compute_ranks(double *restrict data, double *restrict ranks, unsigned int n) {
    RankItem_cor_test *restrict items = safemalloc(n * sizeof(RankItem_cor_test));
    for (unsigned int i = 0; i < n; i++) {
        items[i].val = data[i];
        items[i].index = i;
    }
    qsort(items, n, sizeof(RankItem_cor_test), compare_rank);
    // Handle ties by averaging ranks
    for (unsigned int i = 0; i < n; ) {
        unsigned int j = i + 1;
        while (j < n && items[j].val == items[i].val) j++;
        double avg_rank = (i + 1 + j) / 2.0;
        for (int k = i; k < j; k++) items[k].rank = avg_rank;
        i = j;
    }
    
    qsort(items, n, sizeof(RankItem_cor_test), compare_index);
    for (unsigned int i = 0; i < n; i++) ranks[i] = items[i].rank;
    Safefree(items);
}
// Generates a single binomial random variate. 
//Uses the standard Bernoulli trial loop. Drand01() taps into Perl's PRNG.
static size_t generate_binomial(size_t size, double prob) {
    if (prob <= 0.0) return 0;
    if (prob >= 1.0) return size;
    
    unsigned int successes = 0;
    for (size_t i = 0; i < size; i++) {
        if (Drand01() <= prob) successes++;
    }
    return successes;
}
// Helper: log combination
static double log_choose(size_t n, size_t k) {
    return lgamma((double)n + 1.0) - lgamma((double)k + 1.0) - lgamma((double)(n - k) + 1.0);
}

static double bisection_root(double (*func)(size_t, size_t, size_t, double),
                             size_t r1, size_t r2, size_t c1, double target,
                             double log_low0, double log_high0) {
    double log_low  = log_low0;
    double log_high = log_high0;
    double best_omega = exp((log_low + log_high) * 0.5);
    double best_error = 1e9;

    for (unsigned short int i = 0; i < 20000; ++i) {
        double log_mid = 0.5 * (log_low + log_high);
        double omega   = exp(log_mid);
        double val     = func(r1, r2, c1, omega);
        double error   = fabs(val - target);

        if (error < best_error) {
            best_error = error;
            best_omega = omega;
        }

        if (val > target) {
            log_high = log_mid;
        } else {
            log_low  = log_mid;
        }
        if (log_high - log_low < 1e-30) break;
    }
    return best_omega;
}
// Expected value using the same stable recursive method
static double expected_a(size_t r1, size_t r2, size_t c1, double omega) {
    size_t min_x = (r2 > c1) ? 0 : c1 - r2;
    size_t max_x = (r1 < c1) ? r1 : c1;
    if (omega <= 0.0) return (double)min_x;

    double p = 1.0, sum_p = 1.0;
    double sum_xp = (double)min_x;
    for (size_t i = min_x; i < max_x; ++i) {
        double ratio = ((double)(r1 - i) * (c1 - i) * omega) /
                       ((i + 1.0) * (r2 - c1 + i + 1.0));
        p *= ratio;
        sum_p += p;
        sum_xp += (double)(i + 1) * p;
    }
    return sum_xp / sum_p;
}

// Tail probabilities using recursive ratio (fast + stable, same as R)/
static void calc_tails(size_t a, size_t b, size_t c, size_t d, double omega, 
                       double *restrict lower_tail, double *restrict upper_tail) {
    size_t r1 = a + b, r2 = c + d, c1 = a + c;
    size_t min_x = (r2 > c1) ? 0 : c1 - r2;
    size_t max_x = (r1 < c1) ? r1 : c1;
    *lower_tail = 0.0;
    *upper_tail = 0.0;
    if (omega <= 0.0) {
        *lower_tail = 1.0;
        *upper_tail = 1.0;
        return;
    }
    double p = 1.0, total = 1.0;
    if (min_x <= a) *lower_tail += p;
    if (min_x >= a) *upper_tail += p;
    for (size_t x = min_x; x < max_x; ++x) {
        double ratio = ((double)(r1 - x) * (c1 - x) * omega) /
                       ((x + 1.0) * (r2 - c1 + x + 1.0));
        p *= ratio;
        total += p;

        size_t curr = x + 1;
        if (curr <= a) *lower_tail += p;
        if (curr >= a) *upper_tail += p;
    }
    double inv = 1.0 / total;
    *lower_tail *= inv;
    *upper_tail *= inv;
}

/* Bisection with best-point tracking (matches R printed precision) */
static void calculate_exact_stats(size_t a, size_t b, size_t c, size_t d, double conf_level,
                                  double *restrict mle_or, double *restrict ci_low, double *restrict ci_high) {
    double alpha = 1.0 - conf_level;
    double target_alpha = alpha / 2.0;

    size_t r1 = a + b, r2 = c + d, c1 = a + c;
    size_t min_x = (r2 > c1) ? 0 : c1 - r2;
    size_t max_x = (r1 < c1) ? r1 : c1;
    /* MLE */
    if (a == min_x && a == max_x) *mle_or = 1.0;
    else if (a == min_x) *mle_or = 0.0;
    else if (a == max_x) *mle_or = INFINITY;
    else *mle_or = bisection_root(expected_a, r1, r2, c1, (double)a, -100.0, 100.0);
    /* Lower CI: P(X ≥ a | ω) = α/2 */
    if (a == min_x) {
        *ci_low = 0.0;
    } else {
        double log_low = -100.0, log_high = 100.0, best = 1.0, best_err = 1e9, lt, ut;
        for (unsigned int i = 0; i < 10000; ++i) {
            double log_mid = 0.5 * (log_low + log_high);
            double mid = exp(log_mid);
            calc_tails(a, b, c, d, mid, &lt, &ut);
            double err = fabs(ut - target_alpha);
            if (err < best_err) { best_err = err; best = mid; }
            if (ut > target_alpha) log_high = log_mid; else log_low = log_mid;
            if (log_high - log_low < 1e-32) break;
        }
        *ci_low = best;
    }
    /* Upper CI: P(X ≤ a | ω) = α/2 */
    if (a == max_x) {
        *ci_high = INFINITY;
    } else {
        double log_low = -100.0, log_high = 100.0, best = 1.0, best_err = 1e9, lt, ut;
        for (unsigned short int i = 0; i < 10000; ++i) {
            double log_mid = 0.5 * (log_low + log_high);
            double mid = exp(log_mid);
            calc_tails(a, b, c, d, mid, &lt, &ut);
            double err = fabs(lt - target_alpha);
            if (err < best_err) { best_err = err; best = mid; }
            if (lt > target_alpha) log_low = log_mid; else log_high = log_mid;
            if (log_high - log_low < 1e-32) break;
        }
        *ci_high = best;
    }
}

// Two-sided exact p-value
static double exact_p_value(size_t a, size_t b, size_t c, size_t d) {
	size_t r1 = a + b, r2 = c + d, c1 = a + c;
	size_t min_x = (r2 > c1) ? 0 : c1 - r2;
	size_t max_x = (r1 < c1) ? r1 : c1;

	double p_obs = exp(log_choose(r1, a) + log_choose(r2, c) - log_choose(r1 + r2, c1));
	double p_val = 0.0;

	for (size_t i = min_x; i <= max_x; i++) {
		double p_cur = exp(log_choose(r1, i) + log_choose(r2, c1 - i) - log_choose(r1 + r2, c1));
		if (p_cur <= p_obs * (1.0 + 1e-7)) {
			p_val += p_cur;
		}
	}
	return (p_val > 1.0) ? 1.0 : p_val;
}
/* -----------------------------------------------------------------------
 * Helpers for lm() Linear Regression: OLS Matrix Math & Formula Parsing
 * ----------------------------------------------------------------------- */

/* Sweep operator for symmetric positive-definite matrices (e.g., XtX).
 * This gracefully handles collinearity by bypassing aliased columns.
 * Matches R's LINPACK/LAPACK coefficient dropping behavior. */
static int sweep_matrix_ols(double *restrict A, size_t n, bool *restrict aliased) {
    int rank = 0;
    for (size_t k = 0; k < n; k++) aliased[k] = false;

    for (size_t k = 0; k < n; k++) {
        /* Check pivot for collinearity / zero variance */
        if (fabs(A[k * n + k]) < 1e-10) {
            aliased[k] = true;
            /* Isolate this column so it doesn't affect the rest of the matrix */
            for (size_t i = 0; i < n; i++) { A[k * n + i] = 0.0; A[i * n + k] = 0.0; }
            continue;
        }
        rank++;
        double pivot = 1.0 / A[k * n + k];
        A[k * n + k] = 1.0;
        
        for (size_t j = 0; j < n; j++) A[k * n + j] *= pivot;
        
        for (size_t i = 0; i < n; i++) {
            if (i != k && A[i * n + k] != 0.0) {
                double factor = A[i * n + k];
                A[i * n + k] = 0.0;
                for (size_t j = 0; j < n; j++) {
                    A[i * n + j] -= factor * A[k * n + j];
                }
            }
        }
    }
    return rank;
}

// Struct for sorting p-values while remembering their original index
typedef struct {
	double p;
	size_t orig_idx;
} PVal;

// Comparator for qsort
static int cmp_pval(const void *restrict a, const void *restrict b) {
    double diff = ((PVal*)a)->p - ((PVal*)b)->p;
    if (diff < 0) return -1;
    if (diff > 0) return 1;
    /* Stabilize sort by falling back to original index */
    return ((PVal*)a)->orig_idx - ((PVal*)b)->orig_idx; 
}
/* -----------------------------------------------------------------------
 * Helpers for cor(): ranking (Spearman), Pearson r, Kendall tau-b
 * ----------------------------------------------------------------------- */
/* Item used to sort values while remembering their original index,
 * needed for average-rank tie-breaking in Spearman correlation.        */
typedef struct {
    double val;
    size_t idx;
} RankItem;

static int cmp_rank_item(const void *restrict a, const void *restrict b) {
    double diff = ((RankItem*)a)->val - ((RankItem*)b)->val;
    if (diff < 0) return -1;
    if (diff > 0) return  1;
    return 0;
}

/* Compute 1-based average ranks with tie-breaking into out[].
 * in[] is not modified.                                                 */
static void rank_data(const double *restrict in, double *restrict out, size_t n) {
	RankItem *restrict ri;
	Newx(ri, n, RankItem);
	for (size_t i = 0; i < n; i++) { ri[i].val = in[i]; ri[i].idx = i; }
	qsort(ri, n, sizeof(RankItem), cmp_rank_item);

	size_t i = 0;
	while (i < n) {
	  size_t j = i;
	  /* Find the full extent of this tie group */
	  while (j + 1 < n && ri[j + 1].val == ri[j].val) j++;
	  /* All members get the average of ranks i+1 … j+1 (1-based) */
	  double avg = (double)(i + j) / 2.0 + 1.0;
	  for (size_t k = i; k <= j; k++) out[ri[k].idx] = avg;
	  i = j + 1;
	}
	Safefree(ri);
}

/* Pearson product-moment r between two n-element arrays.
 * Returns NAN when either variable has zero variance (matches R).       */
static double pearson_corr(const double *restrict x, const double *restrict y, size_t n) {
    double sx = 0, sy = 0, sxy = 0, sx2 = 0, sy2 = 0;
    for (size_t i = 0; i < n; i++) {
        sx  += x[i];     sy  += y[i];
        sxy += x[i]*y[i]; sx2 += x[i]*x[i]; sy2 += y[i]*y[i];
    }
    double num = (double)n * sxy - sx * sy;
    double den = sqrt(((double)n * sx2 - sx*sx) * ((double)n * sy2 - sy*sy));
    if (den == 0.0) return NAN;
    return num / den;
}

/* Kendall's tau-b between two n-element arrays.
 *
 *   tau-b = (C − D) / sqrt((C + D + T_x)(C + D + T_y))
 *
 * where C = concordant pairs, D = discordant, T_x = pairs tied only on
 * x, T_y = pairs tied only on y.  Joint ties (both zero) are excluded
 * from numerator and denominator, matching R's cor(method="kendall").
 * Returns NAN when the denominator is zero.                             */
static double kendall_tau_b(const double *restrict x, const double *restrict y, unsigned int n) {
	size_t C = 0, D = 0, tie_x = 0, tie_y = 0;
	for (size_t i = 0; i < n - 1; i++) {
	  for (size_t j = i + 1; j < n; j++) {
		   int sx = (x[i] > x[j]) - (x[i] < x[j]);   /* sign of x[i]-x[j] */
		   int sy = (y[i] > y[j]) - (y[i] < y[j]);
		   if      (sx == 0 && sy == 0) { /* joint tie — not counted */ }
		   else if (sx == 0)            tie_x++;
		   else if (sy == 0)            tie_y++;
		   else if (sx == sy)           C++;
		   else                         D++;
	  }
	}
	double denom = sqrt((double)(C + D + tie_x) * (double)(C + D + tie_y));
	if (denom == 0.0) return NAN;
	return (double)(C - D) / denom;
}

/* Single dispatch: compute correlation according to method string.
 * Allocates and frees temporary rank arrays internally for Spearman.   */
static double compute_cor(const double *restrict x, const double *restrict y,
                           size_t n, const char *restrict method) {
	if (strcmp(method, "spearman") == 0) {
	  double *restrict rx, *restrict ry;
	  Newx(rx, n, double); Newx(ry, n, double);
	  rank_data(x, rx, n);
	  rank_data(y, ry, n);
	  double r = pearson_corr(rx, ry, n);
	  Safefree(rx); Safefree(ry);
	  return r;
	}
	if (strcmp(method, "kendall") == 0)
	  return kendall_tau_b(x, y, n);
	/* default: pearson */
	return pearson_corr(x, y, n);
}

// Math macros
#define MAX_ITER 200
#define EPS 3.0e-7
#define FPMIN 1.0e-30

static double _incbeta_cf(double a, double b, double x) {
	int m;
	double aa, c, d, del, h, qab, qam, qap;
	qab = a + b; qap = a + 1.0; qam = a - 1.0;
	c = 1.0; d = 1.0 - qab * x / qap;
	if (fabs(d) < FPMIN) d = FPMIN;
	d = 1.0 / d; h = d;
	for (m = 1; m <= MAX_ITER; m++) {
	  int m2 = 2 * m;
	  aa = m * (b - m) * x / ((qam + m2) * (a + m2));
	  d = 1.0 + aa * d;
	  if (fabs(d) < FPMIN) d = FPMIN;
	  c = 1.0 + aa / c;
	  if (fabs(c) < FPMIN) c = FPMIN;
	  d = 1.0 / d; h *= d * c;
	  aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
	  d = 1.0 + aa * d;
	  if (fabs(d) < FPMIN) d = FPMIN;
	  c = 1.0 + aa / c;
	  if (fabs(c) < FPMIN) c = FPMIN;
	  d = 1.0 / d; del = d * c; h *= del;
	  if (fabs(del - 1.0) < EPS) break;
	}
	return h;
}

static double incbeta(double a, double b, double x) {
	if (x <= 0.0) return 0.0;
	if (x >= 1.0) return 1.0;
	double bt = exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * log(x) + b * log(1.0 - x));
	if (x < (a + 1.0) / (a + b + 2.0)) return bt * _incbeta_cf(a, b, x) / a;
	return 1.0 - bt * _incbeta_cf(b, a, 1.0 - x) / b;
}

static double get_t_pvalue(double t, double df, const char*restrict alt) {
	double x = df / (df + t * t);
	double prob_2tail = incbeta(df / 2.0, 0.5, x);
	if (strcmp(alt, "less") == 0) return (t < 0) ? 0.5 * prob_2tail : 1.0 - 0.5 * prob_2tail;
	if (strcmp(alt, "greater") == 0) return (t > 0) ? 0.5 * prob_2tail : 1.0 - 0.5 * prob_2tail;
	return prob_2tail;
}

/* Bisection algorithm to find the inverse t-distribution (Critical t-value) */
static double qt_tail(double df, double p_tail) {
	double low = 0.0, high = 1.0;
	/* Find upper bound */
	while (get_t_pvalue(high, df, "greater") > p_tail) {
	  low = high;
	  high *= 2.0;
	  if (high > 1000000.0) break; /* Fallback limit */
	}
	/* Bisect to find the root */
	for (unsigned short int i = 0; i < 100; i++) {
	  double mid = (low + high) / 2.0;
	  double p_mid = get_t_pvalue(mid, df, "greater");
	  if (p_mid > p_tail) {
		   low = mid;
	  } else {
		   high = mid;
	  }
	  if (high - low < 1e-8) break;
	}
	return (low + high) / 2.0;
}

int compare_doubles(const void *restrict a, const void *restrict b) {
	double da = *(const double*restrict)a;
	double db = *(const double*restrict)b;
	return (da > db) - (da < db);
}
/* Helper to calculate the number of bins using Sturges' formula: log2(n) + 1 */
static size_t calculate_sturges_bins(size_t n) {
	if (n == 0) return 1;
	return (size_t)(log((double)n) / log(2.0) + 1.0);
}

// Logic for distributing data into bins (Optimized to O(N))
static void compute_hist_logic(double *restrict x, size_t n, double *restrict breaks, size_t n_bins, 
                               size_t *restrict counts, double *restrict mids, double *restrict density) {
	double total_n = (double)n;
	double min_val = breaks[0];
	double step = (n_bins > 0) ? (breaks[1] - breaks[0]) : 0.0;
	// Initialize counts and compute midpoints
	for (size_t i = 0; i < n_bins; i++) {
	  counts[i] = 0;
	  mids[i] = (breaks[i] + breaks[i+1]) / 2.0;
	}
	// Single O(N) pass to assign elements to bins
	if (step > 0.0) {
	  for (size_t j = 0; j < n; j++) {
		   double val = x[j];
		   // Ignore out-of-bounds or invalid values
		   if (isnan(val) || isinf(val) || val < min_val) continue;
		   // Calculate initial bin index mathematically
		   size_t idx = (size_t)((val - min_val) / step);
		   // Clamp to valid array bounds first to prevent overflow */
		   if (idx >= n_bins) {
		       idx = n_bins - 1;
		   }
		   /* Adjust for exact boundaries (R's right-inclusive default: (a, b]) */
		   /* If value is exactly on or slightly below the lower boundary of the assigned bin, 
		      it belongs in the previous bin. (First bin [a, b] is inclusive on both ends) */
		   while (idx > 0 && val <= breaks[idx]) {
		       idx--;
		   }
		   // Conversely, if floating-point truncation placed it too low, push it up
		   while (idx < n_bins - 1 && val > breaks[idx + 1]) {
		       idx++;
		   }
		   counts[idx]++;
	  }
	} else if (n_bins > 0) {
	  // Edge case: All data points have the exact same value (step == 0)
	  counts[0] = n;
	}
	// Compute densities
	for (size_t i = 0; i < n_bins; i++) {
	  double bin_width = breaks[i+1] - breaks[i];
	  if (bin_width > 0) {
		   density[i] = (double)counts[i] / (total_n * bin_width);
	  } else {
		   density[i] = (n_bins == 1) ? 1.0 : 0.0;
	  }
	}
}

// Standard Normal CDF approximation
double approx_pnorm(double x) {
	return 0.5 * erfc(-x * 0.70710678118654752440); // 0.707... = 1/sqrt(2)
}
#ifndef M_SQRT1_2
#define M_SQRT1_2 0.70710678118654752440
#endif

/* Macro for exact Wilcoxon 3D array indexing */
#define DP_INDEX(i, j, k, n2, max_u) ((i) * ((n2) + 1) * ((max_u) + 1) + (j) * ((max_u) + 1) + (k))
/* Pure C: Beasley-Springer-Moro approximation for inverse normal CDF */
static double inverse_normal_cdf(double p) {
	double a[4] = {2.50662823884, -18.61500062529, 41.39119773534, -25.44106049637};
	double b[4] = {-8.47351093090, 23.08336743743, -21.06224101826, 3.13082909833};
	double c[9] = {0.3374754822726147, 0.9761690190917186, 0.1607979714918209,
		          0.0276438810333863, 0.0038405729373609, 0.0003951896511919,
		          0.0000321767881768, 0.0000002888167364, 0.0000003960315187};
	double x, r, y;
	y = p - 0.5;
	if (fabs(y) < 0.42) {
	  r = y * y;
	  x = y * (((a[3]*r + a[2])*r + a[1])*r + a[0]) /
		       ((((b[3]*r + b[2])*r + b[1])*r + b[0])*r + 1.0);
	} else {
	  r = p;
	  if (y > 0) r = 1.0 - p;
	  r = log(-log(r));
	  x = c[0] + r * (c[1] + r * (c[2] + r * (c[3] + r * (c[4] +
		   r * (c[5] + r * (c[6] + r * (c[7] + r * c[8])))))));
	  if (y < 0) x = -x;
	}
	return x;
}
/* -----------------------------------------------------------------------
 * Exact Spearman p-value via exhaustive permutation enumeration.
 *
 * Under H0, all n! orderings of ranks are equally probable.  We visit
 * every permutation of {1..n} with Heap's algorithm (O(n!), no allocs
 * inside the loop) and count how many yield S ≤ s_obs ("lower tail",
 * i.e. rho ≥ rho_obs) and how many yield S ≥ s_obs ("upper tail").
 *
 * Mirrors R's default: exact = (n < 10) with no ties.
 * Valid up to n = 9 (362 880 iterations — negligible cost).
 * ----------------------------------------------------------------------- */
static double spearman_exact_pvalue(double s_obs, int n, const char *restrict alt) {
    int *restrict perm = (int*)safemalloc(n * sizeof(int));
    int *restrict c    = (int*)safemalloc(n * sizeof(int));
    int  i;
    for (i = 0; i < n; i++) { perm[i] = i + 1; c[i] = 0; }

    long count_le = 0, count_ge = 0, total = 0;

#define TALLY_PERM() do {                                    \
        double s_ = 0.0;                                     \
        for (int ii = 0; ii < n; ii++) {                    \
            double d_ = (double)(ii + 1) - (double)perm[ii];\
            s_ += d_ * d_;                                   \
        }                                                    \
        if (s_ <= s_obs + 1e-9) count_le++;                 \
        if (s_ >= s_obs - 1e-9) count_ge++;                 \
        total++;                                             \
    } while (0)

    TALLY_PERM();   /* initial permutation [1, 2, ..., n] */

    unsigned int k = 1;
    while (k < n) {
        if (c[k] < k) {
            int tmp;
            if (k % 2 == 0) {
                tmp = perm[0]; perm[0] = perm[k]; perm[k] = tmp;
            } else {
                tmp = perm[c[k]]; perm[c[k]] = perm[k]; perm[k] = tmp;
            }
            TALLY_PERM();
            c[k]++;
            k = 1;
        } else {
            c[k] = 0;
            k++;
        }
    }
#undef TALLY_PERM

	Safefree(perm); Safefree(c);
	/* p_le = P(S ≤ s_obs) ≡ P(rho ≥ rho_obs)  — upper rho tail
	* p_ge = P(S ≥ s_obs) ≡ P(rho ≤ rho_obs)  — lower rho tail  */
	double p_le = (double)count_le / (double)total;
	double p_ge = (double)count_ge / (double)total;

	if (strcmp(alt, "greater") == 0) return p_le;
	if (strcmp(alt, "less")    == 0) return p_ge;
	/* two.sided: 2 × the smaller tail, clamped to 1 */
	double p = 2.0 * (p_le < p_ge ? p_le : p_ge);
	return (p > 1.0) ? 1.0 : p;
}
/* -----------------------------------------------------------------------
 * Exact Kendall p-value via Mahonian Numbers (Inversions distribution)
 * Matches R's behavior for N < 50 without ties.
 * ----------------------------------------------------------------------- */
static double kendall_exact_pvalue(size_t n, double s_obs, const char *restrict alt) {
	long max_inv = (long)n * (n - 1) / 2;
	double *restrict dp = (double*)safemalloc((max_inv + 1) * sizeof(double));
	for (long i = 0; i <= max_inv; i++) dp[i] = 0.0;
	dp[0] = 1.0;
	/* Build the distribution of inversions via DP */
	for (size_t i = 2; i <= n; i++) {
	  double *restrict next_dp = (double*)safemalloc((max_inv + 1) * sizeof(double));
	  for (long k = 0; k <= max_inv; k++) next_dp[k] = 0.0;
	  int current_max_inv = i * (i - 1) / 2;
	  for (int k = 0; k <= current_max_inv; k++) {
		   double sum = 0;
		   for (int j = 0; j <= i - 1 && k - j >= 0; j++) {
		       sum += dp[k - j];
		   }
		   // Divide by 'i' directly to keep array as pure probabilities and prevent overflow
		   next_dp[k] = sum / (double)i;
	  }
	  Safefree(dp);
	  dp = next_dp;
	}
	// Convert S statistic to target number of inversions
	long i_obs = (long)round((max_inv - s_obs) / 2.0);
	if (i_obs < 0) i_obs = 0;
	if (i_obs > max_inv) i_obs = max_inv;
	double p_le = 0.0; /* P(S <= S_obs) */
	for (long k = i_obs; k <= max_inv; k++) p_le += dp[k];
	double p_ge = 0.0; /* P(S >= S_obs) */
	for (long k = 0; k <= i_obs; k++) p_ge += dp[k];
	Safefree(dp);
	if (strcmp(alt, "greater") == 0) return p_ge;
	if (strcmp(alt, "less") == 0) return p_le;
	// two.sided
	double p = 2.0 * (p_ge < p_le ? p_ge : p_le);
	return p > 1.0 ? 1.0 : p;
}
// Continued fraction for Incomplete Beta Function (internal helper)
static double betacf(double a, double b, double x) {
	double c, d, h, qab, qam, qap;
	qab = a + b;
	qap = a + 1.0;
	qam = a - 1.0;
	c = 1.0;
	d = 1.0 - qab * x / qap;
	if (fabs(d) < 1e-30) d = 1e-30;
	d = 1.0 / d;
	h = d;
	for (unsigned short int m = 1; m <= 100; m++) {
	  unsigned short int m2 = 2 * m;
	  double aa = m * (b - m) * x / ((qam + m2) * (a + m2));
	  d = 1.0 + aa * d;
	  if (fabs(d) < 1e-30) d = 1e-30;
	  c = 1.0 + aa / c;
	  if (fabs(c) < 1e-30) c = 1e-30;
	  d = 1.0 / d;
	  h *= d * c;
	  aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
	  d = 1.0 + aa * d;
	  if (fabs(d) < 1e-30) d = 1e-30;
	  c = 1.0 + aa / c;
	  if (fabs(c) < 1e-30) c = 1e-30;
	  d = 1.0 / d;
	  double del = d * c;
	  h *= del;
	  if (fabs(del - 1.0) < 3e-7) break;
	}
	return h;
}

// Numerically stable p-value for Student's T (2-tailed)
static double pt_2tail(double t, ssize_t df) {
	if (df <= 0 || isnan(t)) return NAN;
	double x = df / (df + t * t);
	double a = 0.5 * df, b = 0.5;

	// Regularized Incomplete Beta Function I_x(a, b)
	// When t is large, x is small, and this calculates the tail directly
	double bt = exp(lgamma(a + b) - lgamma(a) - lgamma(b) + 
		           a * log(x) + b * log(1.0 - x));

	if (x < (a + 1.0) / (a + b + 2.0)) {
	  return bt * betacf(a, b, x) / a;
	} else {
	  /* This side handles the non-tail cases accurately */
	  return 1.0 - bt * betacf(b, a, 1.0 - x) / b;
	}
}
// F-distribution Cumulative Distribution Function P(F <= f)
static double pf(double f, double df1, double df2) {
	if (f <= 0.0) return 0.0;
	double x = (df1 * f) / (df1 * f + df2);
	return incbeta(df1 / 2.0, df2 / 2.0, x);
}
/* Helper to fetch numeric values for a term from the data HashRef */
static double evaluate_term_aov(HV* data, const char* term, size_t row) {
    SV**restrict svp = hv_fetch(data, term, strlen(term), 0);
    if (svp && SvROK(*svp) && SvTYPE(SvRV(*svp)) == SVt_PVAV) {
        AV*restrict av = (AV*)SvRV(*svp);
        SV**restrict val = av_fetch(av, row, 0);
        return (val && SvOK(*val)) ? SvNV(*val) : 0.0;
    }
    return 0.0;
}

/* Householder QR Decomposition for Sequential Sums of Squares */
static void apply_householder_aov(double** restrict X, double* restrict y, size_t n, int p) {
 for (unsigned int k = 0; k < p && k < n; k++) {
     double max_val = 0;
     for (size_t i = k; i < n; i++) {
         if (fabs(X[i][k]) > max_val) max_val = fabs(X[i][k]);
     }
     if (max_val == 0) continue; /* Collinear or zero column */

     double norm = 0;
     for (size_t i = k; i < n; i++) {
         X[i][k] /= max_val;
         norm += X[i][k] * X[i][k];
     }
     norm = sqrt(norm);
     double s = (X[k][k] > 0) ? -norm : norm;
     double u1 = X[k][k] - s;
     X[k][k] = s * max_val;
     
     for (int j = k + 1; j < p; j++) {
         double dot = u1 * X[k][j];
         for (size_t i = k + 1; i < n; i++) dot += X[i][j] * X[i][k];
         double tau = dot / (s * u1);
         X[k][j] += tau * u1;
         for (size_t i = k + 1; i < n; i++) X[i][j] += tau * X[i][k];
     }
     
     /* Transform the response vector y */
     double dot_y = u1 * y[k];
     for (size_t i = k + 1; i < n; i++) dot_y += y[i] * X[i][k];
     double tau_y = dot_y / (s * u1);
     y[k] += tau_y * u1;
     for (size_t i = k + 1; i < n; i++) y[i] += tau_y * X[i][k];
 }
}
static int fit_wls(double *Z, double *X, double *W, size_t n, size_t p, bool *aliased, double *beta, double *XtWX) {
    double *XtWZ = safecalloc(p, sizeof(double));
    for (size_t i = 0; i < p; i++) {
        for (size_t j = 0; j < p; j++) {
            double sum = 0.0;
            for (size_t k = 0; k < n; k++) sum += X[k * p + i] * X[k * p + j] * W[k];
            XtWX[i * p + j] = sum;
        }
        double sum_z = 0.0;
        for (size_t k = 0; k < n; k++) sum_z += X[k * p + i] * Z[k] * W[k];
        XtWZ[i] = sum_z;
    }

    int rank = sweep_matrix_ols(XtWX, p, aliased);

    for (size_t i = 0; i < p; i++) {
        if (aliased[i]) { beta[i] = NAN; }
        else {
            double sum = 0.0;
            for (size_t j = 0; j < p; j++) if (!aliased[j]) sum += XtWX[i * p + j] * XtWZ[j];
            beta[i] = sum;
        }
    }
    Safefree(XtWZ);
    return rank;
}
// --- XS SECTION ---
MODULE = Stats::LikeR  PACKAGE = Stats::LikeR

PROTOTYPES: ENABLE

SV* _glm_fit(SV* y_ref, SV* x_flat_ref, SV* term_names_ref, SV* row_names_ref, SV* family_sv)
CODE:
{
    AV* y_av = (AV*)SvRV(y_ref);
    AV* x_av = (AV*)SvRV(x_flat_ref);
    AV* terms_av_in = (AV*)SvRV(term_names_ref);
    AV* rn_av = (AV*)SvRV(row_names_ref);

    size_t valid_n = av_len(y_av) + 1;
    size_t p = av_len(terms_av_in) + 1;
    size_t i, j;

    const char* family = SvPV_nolen(family_sv);
    bool is_binom = (strcmp(family, "binomial") == 0);

    double *Y = safemalloc(valid_n * sizeof(double));
    double *X = safemalloc(valid_n * p * sizeof(double));
    char **term_names = safemalloc(p * sizeof(char*));
    char **row_names  = safemalloc(valid_n * sizeof(char*));

    for (i = 0; i < p; i++) {
        term_names[i] = savepv(SvPV_nolen(*av_fetch(terms_av_in, i, 0)));
    }
    for (i = 0; i < valid_n; i++) {
        Y[i] = SvNV(*av_fetch(y_av, i, 0));
        row_names[i] = savepv(SvPV_nolen(*av_fetch(rn_av, i, 0)));
        for (j = 0; j < p; j++) X[i * p + j] = SvNV(*av_fetch(x_av, i * p + j, 0));
    }

    double *XtWX = safecalloc(p * p, sizeof(double));
    bool *aliased = safemalloc(p * sizeof(bool));
    double *beta = safemalloc(p * sizeof(double));

    double *W = safemalloc(valid_n * sizeof(double));
    double *Z = safemalloc(valid_n * sizeof(double));
    double *mu = safemalloc(valid_n * sizeof(double));
    double *eta = safemalloc(valid_n * sizeof(double));

    int final_rank = 0, iter = 0;
    bool converged = false;
    double dev = 0.0, null_dev = 0.0, mean_y = 0.0;

    for (i = 0; i < valid_n; i++) mean_y += Y[i];
    mean_y /= valid_n;

    if (is_binom) {
        for (i = 0; i < valid_n; i++) {
            if (Y[i] > 0) null_dev += Y[i] * log(Y[i] / mean_y);
            if (Y[i] < 1) null_dev += (1.0 - Y[i]) * log((1.0 - Y[i]) / (1.0 - mean_y));
            mu[i] = (Y[i] + 0.5) / 2.0;
        }
        null_dev *= 2.0;

        double dev_old = 1e9;
        for (iter = 1; iter <= 25; iter++) {
            for (i = 0; i < valid_n; i++) {
                W[i] = mu[i] * (1.0 - mu[i]);
                if (W[i] < 1e-10) W[i] = 1e-10;
                eta[i] = log(mu[i] / (1.0 - mu[i]));
                Z[i] = eta[i] + (Y[i] - mu[i]) / W[i];
            }
            final_rank = fit_wls(Z, X, W, valid_n, p, aliased, beta, XtWX);

            dev = 0.0;
            for (i = 0; i < valid_n; i++) {
                double et = 0.0;
                for (j = 0; j < p; j++) if (!aliased[j]) et += X[i * p + j] * beta[j];
                mu[i] = 1.0 / (1.0 + exp(-et));
                if (Y[i] > 0) dev += Y[i] * log(Y[i] / mu[i]);
                if (Y[i] < 1) dev += (1.0 - Y[i]) * log((1.0 - Y[i]) / (1.0 - mu[i]));
            }
            dev *= 2.0;
            if (fabs(dev - dev_old) / (0.1 + fabs(dev)) < 1e-8) { converged = true; break; }
            dev_old = dev;
        }
    } else {
        // Gaussian
        for (i = 0; i < valid_n; i++) null_dev += (Y[i] - mean_y)*(Y[i] - mean_y);
        for (i = 0; i < valid_n; i++) { W[i] = 1.0; Z[i] = Y[i]; }
        final_rank = fit_wls(Z, X, W, valid_n, p, aliased, beta, XtWX);
        iter = 2; converged = true; // Matches R's reporting state
        for (i = 0; i < valid_n; i++) {
            double et = 0.0;
            for (j = 0; j < p; j++) if (!aliased[j]) et += X[i * p + j] * beta[j];
            mu[i] = et;
            dev += (Y[i] - mu[i])*(Y[i] - mu[i]);
        }
    }

    HV *res_hv = newHV(), *coef_hv = newHV(), *fitted_hv = newHV();
    HV *resid_hv = newHV(), *dev_resid_hv = newHV(), *summary_hv = newHV();
    AV *terms_av = newAV();

    int df_res = valid_n - final_rank;
    double rse_sq = (df_res > 0) ? (dev / df_res) : NAN;
    double dispersion = is_binom ? 1.0 : rse_sq;

    for (i = 0; i < valid_n; i++) {
        double res = Y[i] - mu[i];
        hv_store(fitted_hv, row_names[i], strlen(row_names[i]), newSVnv(mu[i]), 0);
        hv_store(resid_hv,  row_names[i], strlen(row_names[i]), newSVnv(res), 0);

        double dev_res = 0.0;
        if (is_binom) {
            double di = 0.0;
            if (Y[i] > 0) di += Y[i] * log(Y[i] / mu[i]);
            if (Y[i] < 1) di += (1.0 - Y[i]) * log((1.0 - Y[i]) / (1.0 - mu[i]));
            di = sqrt(2.0 * di);
            dev_res = (res > 0) ? di : -di;
        } else {
            dev_res = res;
        }
        hv_store(dev_resid_hv, row_names[i], strlen(row_names[i]), newSVnv(dev_res), 0);
    }

    for (j = 0; j < p; j++) {
        hv_store(coef_hv, term_names[j], strlen(term_names[j]), newSVnv(beta[j]), 0);
        av_push(terms_av, newSVpv(term_names[j], 0));

        HV *row_hv = newHV();
        if (aliased[j]) {
            hv_store(row_hv, "Estimate", 8, newSVpv("NaN", 0), 0);
            hv_store(row_hv, "Std. Error", 10, newSVpv("NaN", 0), 0);
            hv_store(row_hv, is_binom ? "z value" : "t value", 7, newSVpv("NaN", 0), 0);
            hv_store(row_hv, is_binom ? "Pr(>|z|)" : "Pr(>|t|)", 8, newSVpv("NaN", 0), 0);
        } else {
            double se = sqrt(dispersion * XtWX[j * p + j]);
            double t_val = beta[j] / se;
            double p_val = is_binom ? (2.0 * (1.0 - approx_pnorm(fabs(t_val)))) : pt_2tail(t_val, df_res);

            hv_store(row_hv, "Estimate", 8, newSVnv(beta[j]), 0);
            hv_store(row_hv, "Std. Error", 10, newSVnv(se), 0);
            hv_store(row_hv, is_binom ? "z value" : "t value", 7, newSVnv(t_val), 0);
            hv_store(row_hv, is_binom ? "Pr(>|z|)" : "Pr(>|t|)", 8, newSVnv(p_val), 0);
        }
        hv_store(summary_hv, term_names[j], strlen(term_names[j]), newRV_noinc((SV*)row_hv), 0);
    }

    double aic = is_binom ? (dev + 2.0 * final_rank) : 
                 (valid_n * (log(2.0 * M_PI) + 1.0 - log(valid_n) + log(dev)) + 2.0 * (final_rank + 1));

    hv_store(res_hv, "coefficients",  12, newRV_noinc((SV*)coef_hv), 0);
    hv_store(res_hv, "fitted.values", 13, newRV_noinc((SV*)fitted_hv), 0);
    hv_store(res_hv, "residuals",      9, newRV_noinc((SV*)resid_hv), 0);
    hv_store(res_hv, "deviance.resid",14, newRV_noinc((SV*)dev_resid_hv), 0);
    hv_store(res_hv, "df.residual",   11, newSVuv(df_res), 0);
    hv_store(res_hv, "df.null",        7, newSVuv(valid_n - 1), 0);
    hv_store(res_hv, "rank",           4, newSVuv(final_rank), 0);
    hv_store(res_hv, "rss",            3, newSVnv(dev), 0);
    hv_store(res_hv, "deviance",       8, newSVnv(dev), 0);
    hv_store(res_hv, "null.deviance", 13, newSVnv(null_dev), 0);
    hv_store(res_hv, "summary",        7, newRV_noinc((SV*)summary_hv), 0);
    hv_store(res_hv, "terms",          5, newRV_noinc((SV*)terms_av), 0);
    hv_store(res_hv, "family",         6, newSVpv(family, 0), 0);
    hv_store(res_hv, "iter",           4, newSVuv(iter), 0);
    hv_store(res_hv, "converged",      9, newSViv(converged ? 1 : 0), 0);
    hv_store(res_hv, "aic",            3, newSVnv(aic), 0);

    for (i = 0; i < p; i++) Safefree(term_names[i]);
    Safefree(term_names);
    for (i = 0; i < valid_n; i++) Safefree(row_names[i]);
    Safefree(row_names);

    Safefree(X); Safefree(Y); Safefree(XtWX); Safefree(beta); Safefree(aliased);
    Safefree(W); Safefree(Z); Safefree(mu); Safefree(eta);

    RETVAL = newRV_noinc((SV*)res_hv);
}
OUTPUT:
    RETVAL

SV* cor_test(...)
CODE:
{
	if (items % 2 != 0)
	  croak("Usage: cor_test(x => \\@data1, y => \\@data2, method => 'pearson', ...)");
	SV *restrict x_ref = NULL, *restrict y_ref = NULL;
	const char *restrict alternative = "two.sided";
	const char *restrict method = "pearson";
	SV *restrict exact_sv = NULL;
	double conf_level = 0.95;
	int continuity = 0;
	/* Parse named arguments from the flat stack */
	for (unsigned short int i = 0; i < items; i += 2) {
	  const char *restrict key = SvPV_nolen(ST(i));
	  SV *restrict val = ST(i + 1);

	  if      (strEQ(key, "x"))           x_ref = val;
	  else if (strEQ(key, "y"))           y_ref = val;
	  else if (strEQ(key, "alternative")) alternative = SvPV_nolen(val);
	  else if (strEQ(key, "method"))      method = SvPV_nolen(val);
	  else if (strEQ(key, "exact"))       exact_sv = val;
	  else if (strEQ(key, "conf.level") || strEQ(key, "conf_level")) conf_level = SvNV(val);
	  else if (strEQ(key, "continuity"))  continuity = SvTRUE(val);
	  else croak("cor_test: unknown argument '%s'", key);
	}

	if (!x_ref || !y_ref) croak("cor_test: 'x' and 'y' are required array references");
	AV *restrict x_av, *restrict y_av;
	double *restrict x, *restrict y;
	double estimate = 0, p_value = 0, statistic = 0, df = 0, ci_lower = 0, ci_upper = 0;
	bool is_pearson  = (strcmp(method, "pearson") == 0);
	bool is_kendall  = (strcmp(method, "kendall") == 0);
	bool is_spearman = (strcmp(method, "spearman") == 0);
	HV *restrict rhv;
	if (!SvROK(x_ref) || SvTYPE(SvRV(x_ref)) != SVt_PVAV ||
	  !SvROK(y_ref) || SvTYPE(SvRV(y_ref)) != SVt_PVAV) {
	  croak("x and y must be array references");
	}
	x_av = (AV*)SvRV(x_ref);
	y_av = (AV*)SvRV(y_ref);
	size_t n = av_len(x_av) + 1;
	if (n != av_len(y_av) + 1) croak("incompatible dimensions");
	if (n < 3) croak("not enough finite observations");
	x = safemalloc(n * sizeof(double));
	y = safemalloc(n * sizeof(double));
	for (size_t i = 0; i < n; i++) {
	  SV **restrict x_val = av_fetch(x_av, i, 0);
	  SV **restrict y_val = av_fetch(y_av, i, 0);
	  x[i] = x_val && SvOK(*x_val) ? SvNV(*x_val) : 0;
	  y[i] = y_val && SvOK(*y_val) ? SvNV(*y_val) : 0;
	}

	if (is_pearson) {
	  /* Welford's Method for Pearson Correlation */
	  double mean_x = 0.0, mean_y = 0.0, M2_x = 0.0, M2_y = 0.0, cov = 0.0;
	  for (size_t i = 0; i < n; i++) {
		   double dx = x[i] - mean_x;
		   mean_x += dx / (i + 1);
		   double dy = y[i] - mean_y;
		   mean_y += dy / (i + 1);
		   M2_x += dx * (x[i] - mean_x);
		   M2_y += dy * (y[i] - mean_y);
		   cov  += dx * (y[i] - mean_y);
	  }
	  estimate = (M2_x > 0.0 && M2_y > 0.0) ? cov / sqrt(M2_x * M2_y) : 0.0;
	  df = n - 2;
	  statistic = estimate * sqrt(df / (1.0 - estimate * estimate));
	  
	  /* Confidence interval using Fisher's Z transform */
	  double z = 0.5 * log((1.0 + estimate) / (1.0 - estimate));
	  double se = 1.0 / sqrt(n - 3);
	  double alpha = 1.0 - conf_level;
	  double q = qnorm(1.0 - alpha/2.0);
	  ci_lower = tanh(z - q * se);
	  ci_upper = tanh(z + q * se);
	  
	  /* HIGH-PRECISION P-VALUE USING INCOMPLETE BETA */
	  p_value = get_t_pvalue(statistic, df, alternative);
	} else if (is_kendall) {
	  int c = 0, d = 0, tie_x = 0, tie_y = 0;
	  for (size_t i = 0; i < n - 1; i++) {
		   for (size_t j = i + 1; j < n; j++) {
		       double sign_x = (x[i] - x[j] > 0) - (x[i] - x[j] < 0);
		       double sign_y = (y[i] - y[j] > 0) - (y[i] - y[j] < 0);
		       if (sign_x == 0 && sign_y == 0) { /* Joint tie, ignore */ }
		       else if (sign_x == 0) tie_x++;
		       else if (sign_y == 0) tie_y++;
		       else if (sign_x * sign_y > 0) c++;
		       else d++;
		   }
	  }
	  double denom = sqrt((double)(c + d + tie_x) * (double)(c + d + tie_y));
	  estimate = (denom == 0.0) ? (0.0/0.0) : (double)(c - d) / denom;
	  bool has_ties = (tie_x > 0 || tie_y > 0);
	  bool do_exact;
	  
	  /* Mirror R: exact defaults to TRUE if N < 50 and NO ties */
	  if (!exact_sv || !SvOK(exact_sv)) {
		   do_exact = (n < 50) && !has_ties;
	  } else {
		   do_exact = SvTRUE(exact_sv) ? 1 : 0;
	  }
	  // If forced exact but ties exist, R overrides and falls back to approximation anyway
	  if (do_exact && has_ties) do_exact = 0;
	  
	  if (do_exact) {
		   double S_stat = c - d;
		   statistic = c;
		   p_value = kendall_exact_pvalue(n, S_stat, alternative);
	  } else {
		   /* Normal approximation for large N or ties */
		   double var_S = n * (n - 1) * (2.0 * n + 5.0) / 18.0;
		   double S = c - d;
		   if (continuity) S -= (S > 0 ? 1 : -1);
		   statistic = S / sqrt(var_S);

		   if (strcmp(alternative, "two.sided") == 0) {
		       p_value = 2.0 * (1.0 - approx_pnorm(fabs(statistic)));
		   } else if (strcmp(alternative, "less") == 0) {
		       p_value = approx_pnorm(statistic);
		   } else {
		       p_value = 1.0 - approx_pnorm(statistic);
		   }
	  }
	} else if (is_spearman) {
	  double *restrict rank_x = safemalloc(n * sizeof(double));
	  double *restrict rank_y = safemalloc(n * sizeof(double));
	  compute_ranks(x, rank_x, n);
	  compute_ranks(y, rank_y, n);
	  
	  /* Spearman rho = Pearson r of the ranks (Welford's Method) */
	  double mean_x = 0.0, mean_y = 0.0, M2_x = 0.0, M2_y = 0.0, cov = 0.0;
	  for (size_t i = 0; i < n; i++) {
		   double dx = rank_x[i] - mean_x;
		   mean_x += dx / (i + 1);
		   double dy = rank_y[i] - mean_y;
		   mean_y += dy / (i + 1);
		   M2_x += dx * (rank_x[i] - mean_x);
		   M2_y += dy * (rank_y[i] - mean_y);
		   cov  += dx * (rank_y[i] - mean_y);
	  }
	  estimate = (M2_x > 0.0 && M2_y > 0.0) ? cov / sqrt(M2_x * M2_y) : 0.0;

	  /* S = sum of squared rank differences (R's reported statistic) */
	  double S_stat = 0.0;
	  for (size_t i = 0; i < n; i++) {
		   double diff = rank_x[i] - rank_y[i];
		   S_stat += diff * diff;
	  }

	  /* Ties produce fractional (averaged) ranks — detect them */
	  int has_ties = 0;
	  for (size_t i = 0; i < n; i++) {
		   if (rank_x[i] != floor(rank_x[i]) || rank_y[i] != floor(rank_y[i])) {
		       has_ties = 1;
		       break;
		   }
	  }

	  int do_exact;
	  if (!exact_sv || !SvOK(exact_sv)) {
		   do_exact = (n < 10) && !has_ties;
	  } else {
		   do_exact = SvTRUE(exact_sv) ? 1 : 0;
	  }

	  if (do_exact) {
		   statistic = S_stat;
		   p_value   = spearman_exact_pvalue(S_stat, n, alternative);
	  } else {
		   double r = estimate;
		   if (continuity)
		       r *= (1.0 - 1.0 / (2.0 * (n - 1)));
		   statistic = r * sqrt((n - 2.0) / (1.0 - r * r));
		   p_value = get_t_pvalue(statistic, (double)(n - 2), alternative);
	  }
	  Safefree(rank_x);
	  Safefree(rank_y);
	} else {
	  Safefree(x); Safefree(y);
	  croak("Unknown method");
	}
	Safefree(x);
	Safefree(y);

	rhv = newHV();
	hv_stores(rhv, "estimate", newSVnv(estimate));
	hv_stores(rhv, "p.value", newSVnv(p_value));
	hv_stores(rhv, "statistic", newSVnv(statistic));
	hv_stores(rhv, "method", newSVpv(method, 0));
	hv_stores(rhv, "alternative", newSVpv(alternative, 0));

	if (is_pearson) {
	  hv_stores(rhv, "parameter", newSVnv(df));
	  AV *ci_av = newAV();
	  av_push(ci_av, newSVnv(ci_lower));
	  av_push(ci_av, newSVnv(ci_upper));
	  hv_stores(rhv, "conf.int", newRV_noinc((SV*)ci_av));
	}

	RETVAL = newRV_noinc((SV*)rhv);
}
OUTPUT:
    RETVAL

void
shapiro_test(data)
	SV *data
PREINIT:
	AV *restrict av;
	HV *restrict ret_hash;
	size_t n;
	double *restrict x, w = 0.0, p_val = 0.0, mean = 0.0, ssq = 0.0;
	PPCODE:
	if (!SvROK(data) || SvTYPE(SvRV(data)) != SVt_PVAV) {
	  croak("Expected an array reference");
	}

	av = (AV *)SvRV(data);
	n = av_len(av) + 1;

	if (n < 3 || n > 5000) {
	  croak("Sample size must be between 3 and 5000 (R's limit)");
	}

	Newx(x, n, double);

	// Extract variables and calculate mean
	for (size_t i = 0; i < n; i++) {
	  SV **restrict elem = av_fetch(av, i, 0);
	  if (elem && SvOK(*elem)) {
		   x[i] = SvNV(*elem);
		   mean += x[i];
	  } else {
		   x[i] = 0.0;
	  }
	}
	mean /= n;
	// Calculate Sum of Squares */
	for (size_t i = 0; i < n; i++) {
	  ssq += (x[i] - mean) * (x[i] - mean);
	}
	if (ssq == 0.0) {
	  Safefree(x);
	  croak("Data is perfectly constant; cannot compute Shapiro-Wilk test");
	}
	qsort(x, n, sizeof(double), compare_doubles);
	// --- Core AS R94 Algorithm: Weights and Statistic W ---
	if (n == 3) {
	  double a_val = 0.7071067811865475; /* sqrt(1/2) */
	  double b_val = a_val * (x[2] - x[0]);
	  w = (b_val * b_val) / ssq;
	  if (w < 0.75) w = 0.75; 
	  // Exact P-value for n=3
	  p_val = 1.90985931710274 * (asin(sqrt(w)) - 1.04719755119660); 
	} else {
	  double *restrict m, *restrict a;
	  double sum_m2 = 0.0, b_val = 0.0;
	  Newx(m, n, double);
	  Newx(a, n, double);
	  for (size_t i = 0; i < n; i++) {
		   m[i] = inverse_normal_cdf((i + 1.0 - 0.375) / (n + 0.25));
		   sum_m2 += m[i] * m[i];
	  }
	  double u = 1.0 / sqrt((double)n);
	  double a_n = -2.706056*pow(u,5) + 4.434685*pow(u,4) - 2.071190*pow(u,3) - 0.147981*pow(u,2) + 0.221157*u + m[n-1]/sqrt(sum_m2);
	  a[n-1] = a_n;
	  a[0]   = -a_n;
	  if (n == 4 || n == 5) {
		   double eps = (sum_m2 - 2.0 * m[n-1]*m[n-1]) / (1.0 - 2.0 * a_n*a_n);
		   for (unsigned int i = 1; i < n-1; i++) {
		       a[i] = m[i] / sqrt(eps);
		   }
	  } else {
		   double a_n1 = -3.582633*pow(u,5) + 5.682633*pow(u,4) - 1.752461*pow(u,3) - 0.293762*pow(u,2) + 0.042981*u + m[n-2]/sqrt(sum_m2);
		   a[n-2] = a_n1;
		   a[1]   = -a_n1;
		   double eps = (sum_m2 - 2.0 * m[n-1]*m[n-1] - 2.0 * m[n-2]*m[n-2]) / (1.0 - 2.0 * a_n*a_n - 2.0 * a_n1*a_n1);
		   for (unsigned int i = 2; i < n-2; i++) {
		       a[i] = m[i] / sqrt(eps);
		   }
	  }
	  for (size_t i = 0; i < n; i++) {
		   b_val += a[i] * x[i];
	  }
	  w = (b_val * b_val) / ssq;
	// --- AS R94 P-Value Calculation: High Precision Refinement ---
	  /* NOTE: p_val is declared in PREINIT above; do NOT shadow it with a
		* local 'double p_val' here or the result will never reach the caller. */
	  double y = log(1.0 - w);
	  double z;
	  if (n <= 11) {
		   // Royston's branch for 4 <= n <= 11 (AS R94, small-sample path).
		   // gamma is the upper bound on y = log(1-W); if y reaches gamma
		   // the p-value is essentially zero
		   double nn = (double)n;
		   double gamma = 0.459 * nn - 2.273;
		   if (y >= gamma) {
		       p_val = 1e-19;
		   } else {
		       // Horner-form polynomials in n for mu and log(sigma)
		       double mu     = 0.544  + nn * (-0.39978  + nn * ( 0.025054  - nn * 0.0006714));
		       double sig_val= 1.3822 + nn * (-0.77857  + nn * ( 0.062767  - nn * 0.0020322));
		       double sigma  = exp(sig_val);
		       z = (-log(gamma - y) - mu) / sigma;
		       /* Upper-tail probability P(Z > z): small W → large z → small p-value. */
		       p_val = 0.5 * erfc(z * M_SQRT1_2);
		   }
	  } else {
		   // Royston's branch for n >= 12 (AS R94, large-sample path)
		   double ln_n   = log((double)n);
		   // Horner-form polynomials in log(n) for mu and log(sigma). */
		   double mu     = -1.5861 + ln_n * (-0.31082 + ln_n * (-0.083751 + ln_n * 0.0038915));
		   double sig_val= -0.4803 + ln_n * (-0.082676 + ln_n * 0.0030302);
		   double sigma  = exp(sig_val);
		   z = (y - mu) / sigma;
		   p_val = 0.5 * erfc(z * M_SQRT1_2);
	  }
	  // Clamp the p-value
	  if (p_val > 1.0) p_val = 1.0;
	  if (p_val < 0.0) p_val = 0.0;
	  
	  Safefree(m); m = NULL;  Safefree(a); a = NULL;
	}
	Safefree(x); x = NULL;
	ret_hash = newHV();
	hv_stores(ret_hash, "statistic", newSVnv(w));
	hv_stores(ret_hash, "W",         newSVnv(w));
	hv_stores(ret_hash, "p_value",   newSVnv(p_val));
	hv_stores(ret_hash, "p.value",   newSVnv(p_val));
	EXTEND(SP, 1);
	PUSHs(sv_2mortal(newRV_noinc((SV *)ret_hash)));

double min(...)
	PROTOTYPE: @
	INIT:
		double min_val = 0.0;
		size_t count = 0;
		bool first = TRUE;
	CODE:
	  for (unsigned short int i = 0; i < items; i++) {
		   SV* restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV* restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV** restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) {
		               double val = SvNV(*tv);
		               if (first || val < min_val) {
		                   min_val = val;
		                   first = FALSE;
		               }
		               count++;
		           }
		       }
		   } else if (SvOK(arg)) {
		       double val = SvNV(arg);
		       if (first || val < min_val) {
		           min_val = val;
		           first = FALSE;
		       }
		       count++;
		   }
	  }
	  if (count == 0) croak("min needs >= 1 numeric element");
	  RETVAL = min_val;
	OUTPUT:
	  RETVAL

double max(...)
	PROTOTYPE: @
	INIT:
	  double max_val = 0.0;
	  size_t count = 0;
	  bool first = TRUE;
	CODE:
	  for (unsigned short int i = 0; i < items; i++) {
		   SV* restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV* restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV** restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) {
		               double val = SvNV(*tv);
		               if (first || val > max_val) {
		                   max_val = val;
		                   first = FALSE;
		               }
		               count++;
		           }
		       }
		   } else if (SvOK(arg)) {
		       double val = SvNV(arg);
		       if (first || val > max_val) {
		           max_val = val;
		           first = FALSE;
		       }
		       count++;
		   }
	  }
	  if (count == 0) croak("max needs >= 1 numeric element");
	  RETVAL = max_val;
	OUTPUT:
	  RETVAL

SV* runif(...)
	CODE:
	{
	  // Auto-seed the PRNG if the Perl script hasn't done so yet
	  AUTO_SEED_PRNG();

	  if (items % 2 != 0)
		   croak("Usage: runif(n => 10, min => 0, max => 1)");

	  // --- Parse named arguments ---
	  size_t n = 0;
	  double min = 0.0, max = 1.0;

	  for (unsigned short int i = 0; i < items; i += 2) {
		   const char* restrict key = SvPV_nolen(ST(i));
		   SV* restrict val = ST(i + 1);
		   if      (strEQ(key, "n"))    n   = (size_t)SvUV(val);
		   else if (strEQ(key, "min"))  min = SvNV(val);
		   else if (strEQ(key, "max"))  max = SvNV(val);
		   else croak("runif: unknown argument '%s'", key);
	  }

	  if (min > max) croak("runif: min must be less than or equal to max");
	  
	  AV *restrict result_av = newAV();
	  if (n > 0) {
		   av_extend(result_av, n - 1);
		   double range = max - min;
		   
		   for (size_t i = 0; i < n; i++) {
		       // Transform standard [0,1) uniform to [min, max)
		       av_store(result_av, i, newSVnv(min + range * Drand01()));
		   }
	  }
	  RETVAL = newRV_noinc((SV*)result_av);
	}
	OUTPUT:
	  RETVAL

SV* rbinom(...)
	CODE:
	{
	  // Auto-seed the PRNG if the Perl script hasn't done so yet
	  AUTO_SEED_PRNG();
	  if (items % 2 != 0)
		   croak("Usage: rbinom(n => 10, size => 100, prob => 0.5)");
	  //Parse named arguments
	  size_t n = 0, size = 0;
	  double prob = 0.5;
	  
	  bool size_set = false, prob_set = false;

	  for (unsigned short i = 0; i < items; i += 2) {
		   const char* restrict key = SvPV_nolen(ST(i));
		   SV* restrict val = ST(i + 1);

		   if      (strEQ(key, "n"))      n    = (unsigned int)SvUV(val);
		   else if (strEQ(key, "size")) { size = (unsigned int)SvUV(val); size_set = true; }
		   else if (strEQ(key, "prob")) { prob = SvNV(val); prob_set = true; }
		   else croak("rbinom: unknown argument '%s'", key);
	  }

	  // R requires size and prob to be explicitly passed in rbinom
	  if (!size_set || !prob_set) croak("rbinom: 'size' and 'prob' are required arguments");
	  if (prob < 0.0 || prob > 1.0) croak("rbinom: prob must be between 0 and 1");

	  AV *restrict result_av = newAV();
	  if (n > 0) {
		   av_extend(result_av, n - 1);
		   for (unsigned int i = 0; i < n; i++) {
		       av_store(result_av, i, newSVuv(generate_binomial(size, prob)));
		   }
	  }

	  RETVAL = newRV_noinc((SV*)result_av);
	}
	OUTPUT:
	  RETVAL

SV*
hist(SV* x_sv, ...)
	CODE:
	{
	  /* 1. Validate Input */
	  if (!SvROK(x_sv) || SvTYPE(SvRV(x_sv)) != SVt_PVAV)
		   croak("hist: first argument must be an array reference");
	  
	  AV*restrict x_av = (AV*)SvRV(x_sv);
	  size_t n_raw = av_len(x_av) + 1;
	  if (n_raw == 0) croak("hist: input array is empty");

	  /* 2. Extract Data & Find Range */
	  double *restrict x;
	  Newx(x, n_raw, double);
	  size_t n = 0;
	  double min_val = DBL_MAX, max_val = -DBL_MAX;

	  for (size_t i = 0; i < n_raw; i++) {
		   SV**restrict tv = av_fetch(x_av, i, 0);
		   if (tv && SvOK(*tv)) {
		       double val = SvNV(*tv);
		       x[n++] = val;
		       if (val < min_val) min_val = val;
		       if (val > max_val) max_val = val;
		   }
	  }
	  if (n == 0) {
		   Safefree(x);
		   croak("hist: input contains no valid numeric data");
	  }
	  /* 3. Determine Bin Count (Sturges default or user-provided) */
	  size_t n_bins = 0;
	  
	  if (items == 2) {
		   /* Support pure positional argument: hist($data, 22) */
		   n_bins = (size_t)SvIV(ST(1));
	  } else if (items > 2) {
		   /* Support named parameters even if mixed with positional arguments */
		   for (unsigned short i = 1; i < items - 1; i++) {
		       /* Make sure the SV holds a string before doing string comparison */
		       if (SvPOK(ST(i)) && strEQ(SvPV_nolen(ST(i)), "breaks")) {
		           n_bins = (size_t)SvIV(ST(i+1));
		           break;
		       }
		   }
		   /* Fallback: if 'breaks' wasn't found but a positional number was given first */
		   if (n_bins == 0 && looks_like_number(ST(1))) {
		       n_bins = (size_t)SvIV(ST(1));
		   }
	  }
	  if (n_bins == 0) n_bins = calculate_sturges_bins(n);
	  // 4. Allocate Result Arrays
	  double *restrict breaks, *restrict mids, *restrict density;
	  size_t *restrict counts;
	  Newx(breaks,  n_bins + 1, double);
	  Newx(mids,    n_bins,     double);
	  Newx(density, n_bins,     double);
	  Newx(counts,  n_bins,     size_t);

	  // Generate simple linear breaks
	  double step = (max_val - min_val) / (double)n_bins;
	  for (size_t i = 0; i <= n_bins; i++) {
		   breaks[i] = min_val + (double)i * step;
	  }

	  // 5. Compute Statistics
	  compute_hist_logic(x, n, breaks, n_bins, counts, mids, density);

	  // 6. Build Return HashRef
	  HV*restrict res_hv = newHV();
	  AV*restrict av_breaks  = newAV();
	  AV*restrict av_counts  = newAV();
	  AV*restrict av_mids    = newAV();
	  AV*restrict av_density = newAV();
	  for (size_t i = 0; i <= n_bins; i++) {
		   av_push(av_breaks, newSVnv(breaks[i]));
		   if (i < n_bins) {
		       av_push(av_counts,  newSViv(counts[i]));
		       av_push(av_mids,    newSVnv(mids[i]));
		       av_push(av_density, newSVnv(density[i]));
		   }
	  }
	  hv_stores(res_hv, "breaks",  newRV_noinc((SV*)av_breaks));
	  hv_stores(res_hv, "counts",  newRV_noinc((SV*)av_counts));
	  hv_stores(res_hv, "mids",    newRV_noinc((SV*)av_mids));
	  hv_stores(res_hv, "density", newRV_noinc((SV*)av_density));

	  // Clean
	  Safefree(x); Safefree(breaks); Safefree(mids);
	  Safefree(density); Safefree(counts);

	  RETVAL = newRV_noinc((SV*)res_hv);
	}
	OUTPUT:
	  RETVAL

SV* quantile(...)
	CODE:
	{
	  if (items % 2 != 0 && items != 1) 
		   croak("Usage: quantile(x => \\@data, probs => \\@probs)");
	  SV *restrict x_sv = NULL;
	  SV *restrict probs_sv = NULL;
	  /* --- Parse named arguments --- */
	  if (items == 1) {
		   x_sv = ST(0);
	  } else {
		   for (size_t i = 0; i < items; i += 2) {
		       const char *restrict key = SvPV_nolen(ST(i));
		       SV *restrict val = ST(i + 1);
		       
		       if      (strEQ(key, "x"))     x_sv = val;
		       else if (strEQ(key, "probs")) probs_sv = val;
		       else croak("quantile: unknown argument '%s'", key);
		   }
	  }
	  if (!x_sv || !SvROK(x_sv) || SvTYPE(SvRV(x_sv)) != SVt_PVAV)
		   croak("quantile: 'x' must be an array reference");
	  AV *restrict x_av = (AV*)SvRV(x_sv);
	  size_t n_raw = av_len(x_av) + 1;
	  if (n_raw == 0) croak("quantile: 'x' is empty");

	  /* --- Extract valid numeric data & drop NAs --- */
	  double *restrict x;
	  Newx(x, n_raw, double);
	  size_t n = 0;
	  for (size_t i = 0; i < n_raw; i++) {
		   SV **restrict tv = av_fetch(x_av, i, 0);
		   if (tv && SvOK(*tv)) {
		       x[n++] = SvNV(*tv);
		   }
	  }
	  if (n == 0) {
		   Safefree(x);
		   croak("quantile: 'x' contains no valid numbers");
	  }
	  // --- Sort Data for Quantile Math ---
	  qsort(x, n, sizeof(double), compare_doubles);
	  // --- Parse Probabilities (Default matches R's c(0, .25, .5, .75, 1)) ---
	  double default_probs[] = {0.0, 0.25, 0.50, 0.75, 1.0};
	  unsigned int n_probs = 5;
	  double *restrict probs;

	  if (probs_sv && SvROK(probs_sv) && SvTYPE(SvRV(probs_sv)) == SVt_PVAV) {
		   AV *restrict p_av = (AV*)SvRV(probs_sv);
		   n_probs = av_len(p_av) + 1;
		   Newx(probs, n_probs, double);
		   for (unsigned int i = 0; i < n_probs; i++) {
		       SV **tv = av_fetch(p_av, i, 0);
		       probs[i] = (tv && SvOK(*tv)) ? SvNV(*tv) : 0.0;
		       if (probs[i] < 0.0 || probs[i] > 1.0) {
		           Safefree(x); Safefree(probs);
		           croak("quantile: probabilities must be between 0 and 1");
		       }
		   }
	  } else {
		   Newx(probs, n_probs, double);
		   for (unsigned int i = 0; i < n_probs; i++) probs[i] = default_probs[i];
	  }

	  /* --- Calculate Quantiles (R Type 7 Algorithm) --- */
	  HV *restrict res_hv = newHV();

	  for (size_t i = 0; i < n_probs; i++) {
		   double p = probs[i], q = 0.0;

		   if (n == 1) {
		       q = x[0];
		   } else if (p == 1.0) {
		       q = x[n - 1]; /* Prevent out-of-bounds mapping */
		   } else if (p == 0.0) {
		       q = x[0];
		   } else {
		       /* Continuous sample quantile interpolation (Type 7) */
		       double h = (n - 1) * p;
		       unsigned int j = (unsigned int)h; /* floor via cast */
		       double gamma = h - j;
		       q = (1.0 - gamma) * x[j] + gamma * x[j + 1];
		   }

		   /* Format hash key to exactly match R's naming convention ("25%", "33.3%") */
		   char key[32];
		   double pct = p * 100.0;
		   
		   if (pct == (unsigned int)pct) {
		       snprintf(key, sizeof(key), "%.0f%%", pct);
		   } else {
		       snprintf(key, sizeof(key), "%.1f%%", pct);
		   }

		   hv_store(res_hv, key, strlen(key), newSVnv(q), 0);
	  }

	  Safefree(x);
	  Safefree(probs);

	  RETVAL = newRV_noinc((SV*)res_hv);
	}
	OUTPUT:
	  RETVAL

double mean(...)
	PROTOTYPE: @
	INIT:
	  double total = 0;
	  size_t count = 0;
	CODE:
	  for (size_t i = 0; i < items; i++) {
		   SV*restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV*restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV**restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) { total += SvNV(*tv); count++; }
		       }
		   } else if (SvOK(arg)) {
		       total += SvNV(arg); count++;
		   }
	  }
	  if (count == 0) croak("mean needs >= 1 element");
	  RETVAL = total / count;
	OUTPUT:
	  RETVAL

double sd(...)
	PROTOTYPE: @
	INIT:
	  double mean = 0.0, M2 = 0.0;
	  size_t count = 0;
	CODE:
	  // Single Pass Standard Deviation via Welford's Algorithm
	  for (size_t i = 0; i < items; i++) {
		   SV* restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV*restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV**restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) {
		               count++;
		               double val = SvNV(*tv);
		               double delta = val - mean;
		               mean += delta / count;
		               M2 += delta * (val - mean);
		           }
		       }
		   } else if (SvOK(arg)) {
		       count++;
		       double val = SvNV(arg);
		       double delta = val - mean;
		       mean += delta / count;
		       M2 += delta * (val - mean);
		   }
	  }
	  if (count < 2) croak("stdev needs >= 2 elements");
	  RETVAL = sqrt(M2 / (count - 1));
	OUTPUT:
	  RETVAL

double var(...)
	PROTOTYPE: @
	INIT:
	  double mean = 0.0, M2 = 0.0;
	  size_t count = 0;
	CODE:
	  // Single Pass Variance via Welford's Algorithm
	  for (size_t i = 0; i < items; i++) {
		   SV*restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV*restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV**restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) { 
		               count++;
		               double val = SvNV(*tv);
		               double delta = val - mean;
		               mean += delta / count;
		               M2 += delta * (val - mean);
		           }
		       }
		   } else if (SvOK(arg)) {
		       count++;
		       double val = SvNV(arg);
		       double delta = val - mean;
		       mean += delta / count;
		       M2 += delta * (val - mean);
		   }
	  }
	  if (count < 2) croak("var needs >= 2 elements");
	  RETVAL = M2 / (count - 1);
	OUTPUT:
	  RETVAL

SV* t_test(...)
	CODE:
	{
	  if (items % 2 != 0)
		   croak("Usage: t_test(x => [...], y => [...], ...) - must be even key/value pairs");
		   
	  // --- Parse named arguments from the flat stack
	  SV*restrict x_sv = NULL;
	  SV*restrict y_sv = NULL;
	  double mu = 0.0, conf_level = 0.95;
	  bool paired = FALSE, var_equal = FALSE;
	  const char*restrict alternative = "two.sided";
	  
	  for (unsigned short i = 0; i < items; i += 2) {
		   const char*restrict key = SvPV_nolen(ST(i));
		   SV*restrict val = ST(i + 1);

		   if      (strEQ(key, "x"))           x_sv        = val;
		   else if (strEQ(key, "y"))           y_sv        = val;
		   else if (strEQ(key, "mu"))          mu          = SvNV(val);
		   else if (strEQ(key, "paired"))      paired      = SvTRUE(val);
		   else if (strEQ(key, "var_equal"))   var_equal   = SvTRUE(val);
		   else if (strEQ(key, "conf_level"))  conf_level  = SvNV(val);
		   else if (strEQ(key, "alternative")) alternative = SvPV_nolen(val);
		   else croak("t_test: unknown argument '%s'", key);
	  }
	  
	  // --- Validate required / types ---
	  if (!x_sv || !SvROK(x_sv) || SvTYPE(SvRV(x_sv)) != SVt_PVAV)
		   croak("t_test: 'x' is a required argument and must be an ARRAY reference");
		   
	  AV*restrict x_av = (AV*)SvRV(x_sv);
	  size_t nx = av_len(x_av) + 1;
	  if (nx < 2) croak("t_test: 'x' needs at least 2 elements");
	  
	  AV*restrict y_av = NULL;
	  if (y_sv && SvROK(y_sv) && SvTYPE(SvRV(y_sv)) == SVt_PVAV)
		   y_av = (AV*)SvRV(y_sv);
		   
	  if (conf_level <= 0.0 || conf_level >= 1.0)
		   croak("t_test: 'conf_level' must be between 0 and 1");
		   
	  // --- Computation via Welford's Algorithm --- */
	  double mean_x = 0.0, M2_x = 0.0, var_x, t_stat, df, p_val, std_err, cint_est;
	  HV*restrict results = newHV();

	  for (size_t i = 0; i < nx; i++) {
		   SV**restrict tv = av_fetch(x_av, i, 0);
		   double val = (tv && SvOK(*tv)) ? SvNV(*tv) : 0;
		   double delta = val - mean_x;
		   mean_x += delta / (i + 1);
		   M2_x += delta * (val - mean_x);
	  }
	  var_x = M2_x / (nx - 1);
	  if (var_x == 0.0 && !y_av) croak("t_test: data are essentially constant");
	  
	  if (paired || y_av) {
		   if (!y_av) croak("t_test: 'y' must be provided for paired or two-sample tests");
		   size_t ny = av_len(y_av) + 1;
		   if (paired && ny != nx) croak("t_test: Paired arrays must be same length");
		   
		   double mean_y = 0.0, M2_y = 0.0, var_y;
		   for (size_t i = 0; i < ny; i++) {
		       SV**restrict tv = av_fetch(y_av, i, 0);
		       double val = (tv && SvOK(*tv)) ? SvNV(*tv) : 0;
		       double delta = val - mean_y;
		       mean_y += delta / (i + 1);
		       M2_y += delta * (val - mean_y);
		   }
		   var_y = M2_y / (ny - 1);
		   
		   if (paired) {
		       double mean_d = 0.0, M2_d = 0.0;
		       for (size_t i = 0; i < nx; i++) {
		           double dx = SvNV(*av_fetch(x_av, i, 0));
		           double dy = SvNV(*av_fetch(y_av, i, 0));
		           double val = dx - dy;
		           double delta = val - mean_d;
		           mean_d += delta / (i + 1);
		           M2_d += delta * (val - mean_d);
		       }
		       double var_d = M2_d / (nx - 1);
		       if (var_d == 0.0) croak("t_test: data are essentially constant");
		       
		       cint_est = mean_d;
		       
		       cint_est = mean_d;
		       std_err  = sqrt(var_d / nx);
		       t_stat   = (cint_est - mu) / std_err;
		       df       = nx - 1;
		       hv_store(results, "estimate", 8, newSVnv(mean_d), 0);
		       
			} else if (var_equal) {
		       if (var_x == 0.0 && var_y == 0.0) croak("t_test: data are essentially constant");
		       double pooled_var = ((nx - 1) * var_x + (ny - 1) * var_y) / (nx + ny - 2);
		       cint_est = mean_x - mean_y;
		       std_err  = sqrt(pooled_var * (1.0 / nx + 1.0 / ny));
		       t_stat   = (cint_est - mu) / std_err;
		       df       = nx + ny - 2;
		       
		       hv_store(results, "estimate_x", 10, newSVnv(mean_x), 0);
		       hv_store(results, "estimate_y", 10, newSVnv(mean_y), 0);
		       
		   } else {
		       if (var_x == 0.0 && var_y == 0.0) croak("t_test: data are essentially constant");
		       cint_est         = mean_x - mean_y;
		       double stderr_x2 = var_x / nx;
		       double stderr_y2 = var_y / ny;
		       std_err          = sqrt(stderr_x2 + stderr_y2);
		       t_stat           = (cint_est - mu) / std_err;
		       df = pow(stderr_x2 + stderr_y2, 2) /
		            (pow(stderr_x2, 2) / (nx - 1) + pow(stderr_y2, 2) / (ny - 1));
		            
		       hv_store(results, "estimate_x", 10, newSVnv(mean_x), 0);
		       hv_store(results, "estimate_y", 10, newSVnv(mean_y), 0);
		   }
	  } else {
		   cint_est = mean_x;
		   std_err  = sqrt(var_x / nx);
		   t_stat   = (cint_est - mu) / std_err;
		   df       = nx - 1;
		   hv_store(results, "estimate", 8, newSVnv(mean_x), 0);
	  }

	  p_val = get_t_pvalue(t_stat, df, alternative);

	  double alpha = 1.0 - conf_level, t_crit, ci_lower, ci_upper;
	  
	  if (strcmp(alternative, "less") == 0) {
		   t_crit   = qt_tail(df, alpha);
		   ci_lower = -INFINITY;
		   ci_upper = cint_est + t_crit * std_err;
	  } else if (strcmp(alternative, "greater") == 0) {
		   t_crit   = qt_tail(df, alpha);
		   ci_lower = cint_est - t_crit * std_err;
		   ci_upper = INFINITY;
	  } else {
		   t_crit   = qt_tail(df, alpha / 2.0);
		   ci_lower = cint_est - t_crit * std_err;
		   ci_upper = cint_est + t_crit * std_err;
	  }

	  AV*restrict conf_int = newAV();
	  av_push(conf_int, newSVnv(ci_lower));
	  av_push(conf_int, newSVnv(ci_upper));
	  
	  hv_store(results, "statistic", 9, newSVnv(t_stat), 0);
	  hv_store(results, "df",        2, newSVnv(df),     0);
	  hv_store(results, "p_value",   7, newSVnv(p_val),  0);
	  hv_store(results, "conf_int",  8, newRV_noinc((SV*)conf_int), 0);

	  RETVAL = newRV_noinc((SV*)results);
	}
	OUTPUT:
	  RETVAL

void p_adjust(SV* p_sv, const char* method = "holm")
	INIT:
	  if (!SvROK(p_sv) || SvTYPE(SvRV(p_sv)) != SVt_PVAV) {
		   croak("p_adjust: first argument must be an ARRAY reference of p-values");
	  }
	  AV *restrict p_av = (AV*)SvRV(p_sv);
	  size_t n = av_len(p_av) + 1;
	  // Handle empty input
	  if (n == 0) {
		   XSRETURN_EMPTY;
	  }
	  // Normalize method string
	  char meth[64];
	  strncpy(meth, method, 63); meth[63] = '\0';
	  for(unsigned short int i = 0; meth[i]; i++) meth[i] = tolower(meth[i]);
	  // Resolve aliases
	  if (strstr(meth, "benjamini") && strstr(meth, "hochberg")) strcpy(meth, "bh");
	  if (strstr(meth, "benjamini") && strstr(meth, "yekutieli")) strcpy(meth, "by");
	  if (strcmp(meth, "fdr") == 0) strcpy(meth, "bh");
	  // Allocate C memory
	  PVal *restrict arr;
	  double *restrict adj;
	  Newx(arr, n, PVal);
	  Newx(adj, n, double);

	  for (size_t i = 0; i < n; i++) {
		   SV**restrict tv = av_fetch(p_av, i, 0);
		   arr[i].p = (tv && SvOK(*tv)) ? SvNV(*tv) : 1.0;
		   arr[i].orig_idx = i;
	  }

	  // Sort ascending (Stable sort using original index)
	  qsort(arr, n, sizeof(PVal), cmp_pval);

	PPCODE:
	  if (strcmp(meth, "bonferroni") == 0) {
		   for (size_t i = 0; i < n; i++) {
		       double v = arr[i].p * n;
		       adj[arr[i].orig_idx] = (v < 1.0) ? v : 1.0;
		   }
	  } else if (strcmp(meth, "holm") == 0) {
		   double cummax = 0.0;
		   for (size_t i = 0; i < n; i++) {
		       double v = arr[i].p * (n - i);
		       if (v > cummax) cummax = v;
		       adj[arr[i].orig_idx] = (cummax < 1.0) ? cummax : 1.0;
		   }
	  } else if (strcmp(meth, "hochberg") == 0) {
		   double cummin = 1.0;
		   for (ssize_t i = n - 1; i >= 0; i--) {
		       double v = arr[i].p * (n - i);
		       if (v < cummin) cummin = v;
		       adj[arr[i].orig_idx] = (cummin < 1.0) ? cummin : 1.0;
		   }
	  } else if (strcmp(meth, "bh") == 0) {
		   double cummin = 1.0;
		   for (ssize_t i = n - 1; i >= 0; i--) {
		       double v = arr[i].p * n / (i + 1.0);
		       if (v < cummin) cummin = v;
		       adj[arr[i].orig_idx] = (cummin < 1.0) ? cummin : 1.0;
		   }
	  } else if (strcmp(meth, "by") == 0) {
		   double q = 0.0;
		   for (size_t i = 1; i <= n; i++) q += 1.0 / i;
		   double cummin = 1.0;
		   for (ssize_t i = n - 1; i >= 0; i--) {
		       double v = arr[i].p * n / (i + 1.0) * q;
		       if (v < cummin) cummin = v;
		       adj[arr[i].orig_idx] = (cummin < 1.0) ? cummin : 1.0;
		   }
	  } else if (strcmp(meth, "hommel") == 0) {
		   double *restrict pa, *restrict q_arr;
		   Newx(pa, n, double);
		   Newx(q_arr, n, double);
		   // Initial: min(n * p[i] / (i + 1))
		   double min_val = n * arr[0].p;
		   for (size_t i = 1; i < n; i++) {
		       double temp = (n * arr[i].p) / (i + 1.0);
		       if (temp < min_val) {
		           min_val = temp;
		       }
		   }
		   // pa <- q <- rep(min, n)
		   for (size_t i = 0; i < n; i++) {
		       pa[i] = min_val;
		       q_arr[i] = min_val;
		   }
		   for (size_t j = n - 1; j >= 2; j--) {
		       ssize_t n_mj = n - j;       // Max index for 'ij'. Length is n_mj + 1
		       ssize_t i2_len = j - 1;     // Length of 'i2
		       // Calculate q1 = min(j * p[i2] / (2:j))
		       double q1 = (j * arr[n_mj + 1].p) / 2.0;
		       for (size_t k = 1; k < i2_len; k++) {
		           double temp_q1 = (j * arr[n_mj + 1 + k].p) / (2.0 + k);
		           if (temp_q1 < q1) {
		               q1 = temp_q1;
		           }
		       }
		       // q[ij] <- pmin(j * p[ij], q1)
		       for (size_t i = 0; i <= n_mj; i++) {
		           double v = j * arr[i].p;
		           q_arr[i] = (v < q1) ? v : q1;
		       }
		       // q[i2] <- q[n - j]
		       for (size_t i = 0; i < i2_len; i++) {
		           q_arr[n_mj + 1 + i] = q_arr[n_mj];
		       }
		       // pa <- pmax(pa, q)
		       for (size_t i = 0; i < n; i++) {
		           if (pa[i] < q_arr[i]) {
		              pa[i] = q_arr[i];
		           }
		       }
		   }
		   // pmin(1, pmax(pa, p))[ro] — map sorted results back to original indices
		   for (size_t i = 0; i < n; i++) {
		       double v = (pa[i] > arr[i].p) ? pa[i] : arr[i].p;
		       if (v > 1.0) v = 1.0;
		       adj[arr[i].orig_idx] = v;
		   }
		   Safefree(pa);  Safefree(q_arr);
	  } else if (strcmp(meth, "none") == 0) {
		   for (size_t i = 0; i < n; i++) {
		   	adj[arr[i].orig_idx] = arr[i].p;
		   }
	  } else {
		   Safefree(arr); Safefree(adj);
		   croak("Unknown p-value adjustment method: %s", method);
	  }
	  // Push values onto the Perl stack as a flat list
	  EXTEND(SP, n);
	  for (size_t i = 0; i < n; i++) {
		   PUSHs(sv_2mortal(newSVnv(adj[i])));
	  }
	  Safefree(arr); arr = NULL;
	  Safefree(adj); adj = NULL;

double median(...)
	PROTOTYPE: @
	INIT:
		size_t total_count = 0, k = 0;
		double *restrict nums;
		double median_val = 0.0;
	CODE:
	  // Pass 1: Count total valid elements to allocate memory
	  for (size_t i = 0; i < items; i++) {
		   SV*restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV*restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV**restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) { total_count++; }
		       }
		   } else if (SvOK(arg)) {
		       total_count++;
		   }
	  }
	  if (total_count == 0) croak("median needs >= 1 element");
	  // Allocate C array now that we know the exact size
	  Newx(nums, total_count, double);
	  // Pass 2: Populate the C array
	  for (size_t i = 0; i < items; i++) {
		   SV*restrict arg = ST(i);
		   if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		       AV*restrict av = (AV*)SvRV(arg);
		       size_t len = av_len(av) + 1;
		       for (size_t j = 0; j < len; j++) {
		           SV**restrict tv = av_fetch(av, j, 0);
		           if (tv && SvOK(*tv)) { 
		               nums[k++] = SvNV(*tv); 
		           }
		       }
		   } else if (SvOK(arg)) {
		       nums[k++] = SvNV(arg);
		   }
	  }
	  // Sort and calculate median
	  qsort(nums, total_count, sizeof(double), compare_doubles);
	  if (total_count % 2 == 0) {
		   median_val = (nums[total_count / 2 - 1] + nums[total_count / 2]) / 2.0;
	  } else {
		   median_val = nums[total_count / 2];
	  }
	  Safefree(nums); nums = NULL;
	  RETVAL = median_val;
	OUTPUT:
	  RETVAL

SV* cor(SV* x_sv, SV* y_sv = &PL_sv_undef, const char* method = "pearson")
	INIT:
	  // --- validate method -------------------------------------------
	  if (strcmp(method, "pearson")  != 0 &&
		   strcmp(method, "spearman") != 0 &&
		   strcmp(method, "kendall")  != 0)
		   croak("cor: unknown method '%s' (use 'pearson', 'spearman', or 'kendall')",
		         method);

	  // --- validate x ------------------------------------------------
	  if (!SvROK(x_sv) || SvTYPE(SvRV(x_sv)) != SVt_PVAV)
		   croak("cor: x must be an ARRAY reference");
	  AV*restrict x_av = (AV*)SvRV(x_sv);
	  size_t nx   = av_len(x_av) + 1;
	  if (nx == 0) croak("cor: x is empty");
	  // --- detect whether x is a flat vector or a matrix (AoA) -------
	  bool x_is_matrix = 0;
	  {
		   SV**restrict fp = av_fetch(x_av, 0, 0);
		   if (fp && SvROK(*fp) && SvTYPE(SvRV(*fp)) == SVt_PVAV)
		       x_is_matrix = 1;
	  }
	  // --- detect y ----------------------------
	  bool has_y = (SvOK(y_sv) && SvROK(y_sv) &&
		            SvTYPE(SvRV(y_sv)) == SVt_PVAV);
	  AV*restrict y_av = has_y ? (AV*)SvRV(y_sv) : NULL;
	  size_t ny = has_y ? av_len(y_av) + 1 : 0;
	  bool y_is_matrix = 0;
	  if (has_y && ny > 0) {
		   SV**restrict fp = av_fetch(y_av, 0, 0);
		   if (fp && SvROK(*fp) && SvTYPE(SvRV(*fp)) == SVt_PVAV)
		       y_is_matrix = 1;
	  }
	CODE:// Branch 1: both inputs are flat vectors  →  scalar result
	  if (!x_is_matrix && !y_is_matrix) {
		   if (!has_y) {
		       /* cor(vector) == 1 by definition */
		       RETVAL = newSVnv(1.0);
		   } else {
		       if (nx != ny)
		           croak("cor: x and y must have the same length (%lu vs %lu)",
		                 nx, ny);
		       if (nx < 2)
		           croak("cor: need at least 2 observations");

		       double *restrict xd, *restrict yd;
		       Newx(xd, nx, double);
		       Newx(yd, ny, double);

		       for (size_t i = 0; i < nx; i++) {
		           SV**restrict tv = av_fetch(x_av, i, 0);
		           xd[i] = (tv && SvOK(*tv) && looks_like_number(*tv)) ? SvNV(*tv) : NAN;
		       }
		       for (size_t i = 0; i < ny; i++) {
		           SV**restrict tv = av_fetch(y_av, i, 0);
		           yd[i] = (tv && SvOK(*tv) && looks_like_number(*tv)) ? SvNV(*tv) : NAN;
		       }

		       double r = compute_cor(xd, yd, nx, method);
		       Safefree(xd); Safefree(yd);
		       RETVAL = newSVnv(r);
		   }
	  } else {//Branch 2: x is a matrix (or y is a matrix)  →  AoA result
		   // -- resolve x matrix dimensions
		   if (!x_is_matrix)
		       croak("cor: x must be a matrix (array ref of array refs) "
		             "when y is a matrix");

		   SV**restrict xr0 = av_fetch(x_av, 0, 0);
		   if (!xr0 || !SvROK(*xr0) || SvTYPE(SvRV(*xr0)) != SVt_PVAV)
		       croak("cor: each row of x must be an ARRAY reference");
		   size_t ncols_x = av_len((AV*)SvRV(*xr0)) + 1;
		   if (ncols_x == 0) croak("cor: x matrix has zero columns");
		   size_t nrows   = nx;   /* observations */
		   // PRE-VALIDATION PASS: Ensure all rows are arrays to prevent memory leaks on croak
		   for (size_t i = 0; i < nrows; i++) {
		       SV**restrict rv = av_fetch(x_av, i, 0);
		       if (!rv || !SvROK(*rv) || SvTYPE(SvRV(*rv)) != SVt_PVAV)
		           croak("cor: x row %lu is not an array ref", i);
		   }
		   // -- extract x columns
		   double **restrict col_x;
		   Newx(col_x, ncols_x, double*);
		   for (size_t j = 0; j < ncols_x; j++) {
		       Newx(col_x[j], nrows, double);
		       for (size_t i = 0; i < nrows; i++) {
		           SV**restrict rv = av_fetch(x_av, i, 0);
		           if (!rv || !SvROK(*rv))
		               croak("cor: x row %lu is not an array ref", i);
		           AV*restrict  row = (AV*)SvRV(*rv);
		           SV**restrict cv  = av_fetch(row, j, 0);
		           col_x[j][i] = (cv && SvOK(*cv) && looks_like_number(*cv)) ? SvNV(*cv) : NAN;
		       }
		   }
		   // -- resolve y: separate matrix or re-use x (symmetric)
		   size_t    ncols_y;
		   double **restrict col_y   = NULL;
		   bool symmetric = 0;   // 1 = cor(X) — result is symmetric
		   if (has_y && y_is_matrix) {
		       // cross-correlation: X (nrows × p) vs Y (nrows × q)
		       if (ny != nrows)
		           croak("cor: x and y must have the same number of rows "
		                 "(%lu vs %lu)", nrows, ny);
		       SV**restrict yr0 = av_fetch(y_av, 0, 0);
		       if (!yr0 || !SvROK(*yr0) || SvTYPE(SvRV(*yr0)) != SVt_PVAV)
		           croak("cor: each row of y must be an ARRAY reference");
		       ncols_y = av_len((AV*)SvRV(*yr0)) + 1;
		       if (ncols_y == 0) croak("cor: y matrix has zero columns");

		       Newx(col_y, ncols_y, double*);
		       for (size_t j = 0; j < ncols_y; j++) {
		           Newx(col_y[j], nrows, double);
		           for (size_t i = 0; i < nrows; i++) {
		               SV**restrict  rv = av_fetch(y_av, i, 0);
		               if (!rv || !SvROK(*rv))
		                   croak("cor: y row %lu is not an array ref", i);
		               AV*restrict  row = (AV*)SvRV(*rv);
		               SV**restrict cv  = av_fetch(row, j, 0);
		               col_y[j][i] = (cv && SvOK(*cv) && looks_like_number(*cv)) ? SvNV(*cv) : NAN;
		           }
		       }
		   } else {
		       // cor(X) — symmetric p×p result; share column arrays
		       ncols_y  = ncols_x;
		       col_y    = col_x;
		       symmetric = 1;
		   }
		   if (nrows < 2)
		       croak("cor: need at least 2 observations (got %lu)", nrows);
		   /* -- build cache for symmetric case: compute upper triangle,
		      store results, mirror to lower triangle                    */
		   AV*restrict result_av = newAV();
		   av_extend(result_av, ncols_x - 1);
		   // Allocate per-row AVs up front so we can fill them in order
		   AV **restrict rows_out;
		   Newx(rows_out, ncols_x, AV*);
		   for (size_t i = 0; i < ncols_x; i++) {
		       rows_out[i] = newAV();
		       av_extend(rows_out[i], ncols_y - 1);
		   }
		   if (symmetric) {
		       /* Upper triangle + diagonal, then mirror.
		          r_cache[i][j] (j >= i) holds the computed value.      */
		       double **restrict r_cache;
		       Newx(r_cache, ncols_x, double*);
		       for (size_t i = 0; i < ncols_x; i++)
		           Newx(r_cache[i], ncols_x, double);

		       for (size_t i = 0; i < ncols_x; i++) {
		           r_cache[i][i] = 1.0;                // diagonal
		           for (size_t j = i + 1; j < ncols_x; j++) {
		               double r = compute_cor(col_x[i], col_x[j], nrows, method);
		               r_cache[i][j] = r;
		               r_cache[j][i] = r;              // symmetry
		           }
		       }
		       // fill output AoA from cache
		       for (size_t i = 0; i < ncols_x; i++)
		           for (size_t j = 0; j < ncols_x; j++)
		               av_store(rows_out[i], j, newSVnv(r_cache[i][j]));

		       for (size_t i = 0; i < ncols_x; i++) Safefree(r_cache[i]);
		       Safefree(r_cache); r_cache = NULL;
		   } else {
		       /* cross-correlation: every (i,j) pair is independent     */
		       for (size_t i = 0; i < ncols_x; i++)
		           for (size_t j = 0; j < ncols_y; j++)
		               av_store(rows_out[i], j,
		                        newSVnv(compute_cor(col_x[i], col_y[j],
		                                            nrows, method)));
		   }
		   /* push row AVs into result */
		   for (size_t i = 0; i < ncols_x; i++)
		       av_store(result_av, i, newRV_noinc((SV*)rows_out[i]));
		   Safefree(rows_out); rows_out = NULL;
		   /* -- free column arrays ------------------------------------- */
		   for (size_t j = 0; j < ncols_x; j++) Safefree(col_x[j]);
		   Safefree(col_x); col_x = NULL;
		   if (!symmetric) {
		       for (size_t j = 0; j < ncols_y; j++) Safefree(col_y[j]);
		       Safefree(col_y);
		   }
		   RETVAL = newRV_noinc((SV*)result_av);
	  }
	OUTPUT:
	  RETVAL

void scale(...)
	PROTOTYPE: @
	PPCODE:
	{
	  bool do_center_mean = true, do_scale_sd = true;
	  double center_val = 0.0, scale_val = 1.0;
	  size_t data_items = items;
	  // 1. Parse Options Hash (if it exists as the last argument)
	  if (items > 0) {
		   SV*restrict last_arg = ST(items - 1);
		   if (SvROK(last_arg) && SvTYPE(SvRV(last_arg)) == SVt_PVHV) {
		       data_items = items - 1; // Exclude hash from data processing
		       HV*restrict opt_hv = (HV*)SvRV(last_arg);
		       // --- Parse 'center'
		       SV**restrict center_sv = hv_fetch(opt_hv, "center", 6, 0);
		       if (center_sv) {
		           SV*restrict val_sv = *center_sv;
		           if (!SvOK(val_sv)) {
		               do_center_mean = false; center_val = 0.0;
		           } else {
		               char *restrict str = SvPV_nolen(val_sv);
		               /* Trap booleans and empty strings before numeric checks */
		               if (strcasecmp(str, "mean") == 0 || strcasecmp(str, "true") == 0 || strcmp(str, "1") == 0) {
		                   do_center_mean = true;
		               } else if (strcasecmp(str, "none") == 0 || strcasecmp(str, "false") == 0 || strcmp(str, "0") == 0 || strcmp(str, "") == 0) {
		                   do_center_mean = false; center_val = 0.0;
		               } else if (looks_like_number(val_sv)) {
		                   do_center_mean = false; center_val = SvNV(val_sv);
		               } else if (SvTRUE(val_sv)) {
		                   do_center_mean = true;
		               } else {
		                   do_center_mean = false; center_val = 0.0;
		               }
		           }
		       }
		       // --- Parse 'scale' ---
		       SV**restrict scale_sv = hv_fetch(opt_hv, "scale", 5, 0);
		       if (scale_sv) {
		           SV*restrict val_sv = *scale_sv;
		           if (!SvOK(val_sv)) {
		               do_scale_sd = false; scale_val = 1.0;
		           } else {
		               char *restrict str = SvPV_nolen(val_sv);
		               if (strcasecmp(str, "sd") == 0 || strcasecmp(str, "true") == 0 || strcmp(str, "1") == 0) {
		                   do_scale_sd = true;
		               } else if (strcasecmp(str, "none") == 0 || strcasecmp(str, "false") == 0 || strcmp(str, "0") == 0 || strcmp(str, "") == 0) {
		                   do_scale_sd = false; scale_val = 1.0;
		               } else if (looks_like_number(val_sv)) {
		                   do_scale_sd = false; scale_val = SvNV(val_sv);
		                   if (scale_val == 0.0) scale_val = 1.0; /* Prevent Division By Zero */
		               } else if (SvTRUE(val_sv)) {
		                   do_scale_sd = true;
		               } else {
		                   do_scale_sd = false; scale_val = 1.0;
		               }
		           }
		       }
		   }
	  }
	  // 2. Detect if the input is a Matrix (Array of Arrays)
	  bool is_matrix = false;
	  if (data_items == 1) {
		   SV*restrict first_arg = ST(0);
		   if (SvROK(first_arg) && SvTYPE(SvRV(first_arg)) == SVt_PVAV) {
		       AV*restrict av = (AV*)SvRV(first_arg);
		       if (av_len(av) >= 0) {
		           SV**restrict first_elem = av_fetch(av, 0, 0);
		           if (first_elem && SvROK(*first_elem) && SvTYPE(SvRV(*first_elem)) == SVt_PVAV) {
		               is_matrix = true;
		           }
		       }
		   }
	  }
	  if (is_matrix) {
		   //=========================================================
		   // MATRIX MODE: Scale columns independently (Just like R)
		   //=========================================================
		   AV*restrict mat_av = (AV*)SvRV(ST(0));
		   size_t nrow = av_len(mat_av) + 1, ncol = 0;
		   
		   SV**restrict first_row = av_fetch(mat_av, 0, 0);
		   ncol = av_len((AV*)SvRV(*first_row)) + 1;

		   if (nrow == 0 || ncol == 0) croak("scale requires non-empty matrix");

		   // Create a new matrix for the scaled output
		   AV*restrict result_av = newAV();
		   av_extend(result_av, nrow - 1);
		   AV**restrict row_ptrs = (AV**)safemalloc(nrow * sizeof(AV*));
		   for (size_t r = 0; r < nrow; r++) {
		       row_ptrs[r] = newAV();
		       av_extend(row_ptrs[r], ncol - 1);
		       av_push(result_av, newRV_noinc((SV*)row_ptrs[r]));
		   }
		   // Calculate and apply scale per column
		   for (size_t c = 0; c < ncol; c++) {
		       double col_sum = 0.0;
		       double *restrict col_data;
		       Newx(col_data, nrow, double);
		       // Extract the column data
		       for (size_t r = 0; r < nrow; r++) {
		           SV**restrict row_sv = av_fetch(mat_av, r, 0);
		           if (row_sv && SvROK(*row_sv)) {
		               AV*restrict row_av = (AV*)SvRV(*row_sv);
		               SV**restrict cell_sv = av_fetch(row_av, c, 0);
		               col_data[r] = (cell_sv && SvOK(*cell_sv)) ? SvNV(*cell_sv) : 0.0;
		           } else {
		               col_data[r] = 0.0;
		           }
		           col_sum += col_data[r];
		       }

		       double col_center = do_center_mean ? (col_sum / nrow) : center_val;
		       double col_scale = scale_val;
		       // Calculate Standard Deviation for this specific column if needed
		       if (do_scale_sd) {
		           if (nrow <= 1) {
		               Safefree(col_data);
		               safefree(row_ptrs);
		               croak("scale needs >= 2 rows to calculate standard deviation for a matrix column");
		           }
		           double sum_sq = 0.0;
		           for (size_t r = 0; r < nrow; r++) {
		               double diff = col_data[r] - col_center;
		               sum_sq += diff * diff;
		           }
		           col_scale = sqrt(sum_sq / (nrow - 1));
		       }
		       // Store scaled values back into the new matrix rows
		       for (size_t r = 0; r < nrow; r++) {
		           double centered = col_data[r] - col_center;
		           double final_val = (col_scale == 0.0) ? (0.0 / 0.0) : (centered / col_scale);
		           av_store(row_ptrs[r], c, newSVnv(final_val));
		       }
		       Safefree(col_data);
		   }
		   safefree(row_ptrs);
		   // Push the resulting matrix as a single Reference onto the Perl stack
		   EXTEND(SP, 1);
		   PUSHs(sv_2mortal(newRV_noinc((SV*)result_av)));
	  } else {
		   // ======================================
		   // FLAT LIST MODE: Original functionality
		   // ======================================
		   size_t total_count = 0, k = 0;
		   double *restrict nums;
		   double sum = 0.0;
		   for (size_t i = 0; i < data_items; i++) {
		       SV*restrict arg = ST(i);
		       if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		           AV*restrict av = (AV*)SvRV(arg);
		           size_t len = av_len(av) + 1;
		           for (unsigned int j = 0; j < len; j++) {
		               SV**restrict tv = av_fetch(av, j, 0);
		               if (tv && SvOK(*tv)) { total_count++; }
		           }
		       } else if (SvOK(arg)) {
		           total_count++;
		       }
		   }
		   if (total_count == 0) croak("scale requires at least 1 numeric element");
		   Newx(nums, total_count, double);
		   for (size_t i = 0; i < data_items; i++) {
		       SV*restrict arg = ST(i);
		       if (SvROK(arg) && SvTYPE(SvRV(arg)) == SVt_PVAV) {
		           AV*restrict av = (AV*)SvRV(arg);
		           size_t len = av_len(av) + 1;
		           for (size_t j = 0; j < len; j++) {
		               SV**restrict tv = av_fetch(av, j, 0);
		               if (tv && SvOK(*tv)) { 
		                   double val = SvNV(*tv);
		                   nums[k++] = val; sum += val;
		               }
		           }
		       } else if (SvOK(arg)) {
		           double val = SvNV(arg);
		           nums[k++] = val; sum += val;
		       }
		   }

		   if (do_center_mean) center_val = sum / total_count;

		   if (do_scale_sd) {
		       if (total_count <= 1) {
		           Safefree(nums);
		           croak("scale needs >= 2 elements to calculate SD");
		       }
		       double sum_sq = 0.0;
		       for (size_t i = 0; i < total_count; i++) {
		           double diff = nums[i] - center_val;
		           sum_sq += diff * diff;
		       }
		       scale_val = sqrt(sum_sq / (total_count - 1));
		   }
		   EXTEND(SP, total_count);
		   for (size_t i = 0; i < total_count; i++) {
		       double centered = nums[i] - center_val;
		       double final_val = (scale_val == 0.0) ? (0.0 / 0.0) : (centered / scale_val);
		       PUSHs(sv_2mortal(newSVnv(final_val)));
		   }
		   Safefree(nums); nums = NULL;
	  }
	}

SV* matrix(...) 
CODE:
	// Basic check: must have an even number of arguments for key => value
	if (items % 2 != 0) {
	  croak("Usage: matrix(data => [...], nrow => $n, ncol => $m, byrow => $bool)");
	}
	SV*restrict data_sv = NULL;
	size_t nrow = 0, ncol = 0;
	bool byrow = FALSE, nrow_set = FALSE, ncol_set = FALSE;
	// Parse named arguments
	for (size_t i = 0; i < items; i += 2) {
	  char*restrict key = SvPV_nolen(ST(i));
	  SV*restrict val   = ST(i + 1);
	  if (strEQ(key, "data")) {
		   data_sv = val;
	  } else if (strEQ(key, "nrow")) {
		   nrow = (size_t)SvUV(val);
		   nrow_set = TRUE;
	  } else if (strEQ(key, "ncol")) {
		   ncol = (size_t)SvUV(val);
		   ncol_set = TRUE;
	  } else if (strEQ(key, "byrow")) {
		   byrow = SvTRUE(val);
	  } else {
		   croak("Unknown option: %s", key);
	  }
	}
	// Validate data input
	if (!data_sv || !SvROK(data_sv) || SvTYPE(SvRV(data_sv)) != SVt_PVAV) {
	  croak("The 'data' option must be an array reference (e.g. data => [1..6])");
	}
	AV*restrict data_av = (AV*)SvRV(data_sv);
	size_t data_len = (UV)(av_top_index(data_av) + 1);
	if (data_len == 0) {
	  croak("Data array cannot be empty");
	}
	// R-style dimension inference
	if (!nrow_set && !ncol_set) {
	  nrow = data_len;
	  ncol = 1;
	} else if (nrow_set && !ncol_set) {
	  ncol = (data_len + nrow - 1) / nrow;
	} else if (!nrow_set && ncol_set) {
	  nrow = (data_len + ncol - 1) / ncol;
	}
	// Final safety check for dimensions
	if (nrow == 0 || ncol == 0) {
	  croak("Dimensions must be greater than 0");
	}
	// Create the matrix (Array of Arrays)
	AV*restrict result_av = newAV();
	av_extend(result_av, nrow - 1);
	size_t r, c;// Use unsigned types for counters to prevent negative indexing
	AV**restrict row_ptrs = (AV**restrict)safemalloc(nrow * sizeof(AV*)); /* Pre-allocate row pointers */
	for (size_t r = 0; r < nrow; r++) {
	  row_ptrs[r] = newAV();
	  av_extend(row_ptrs[r], ncol - 1);
	  av_push(result_av, newRV_noinc((SV*)row_ptrs[r]));
	}
	// Fill the matrix
	size_t total_cells = nrow * ncol;
	for (size_t i = 0; i < total_cells; i++) {
	  // Vector recycling logic
	  SV**restrict fetched = av_fetch(data_av, i % data_len, 0);
	  SV*restrict val = fetched ? newSVsv(*fetched) : newSV(0);
	  if (byrow) {
		   r = i / ncol;
		   c = i % ncol;
	  } else {
		   r = i % nrow;
		   c = i / nrow;
	  }
	  av_store(row_ptrs[r], c, val);
	}
	safefree(row_ptrs);
	RETVAL = newRV_noinc((SV*)result_av);
	OUTPUT:
	RETVAL


void
seq(from, to, by = 1.0)
	double from
	double to
	double by
PPCODE:
	{
	  //Handle the zero 'by' case
	  if (by == 0.0) {
		   if (from == to) {
		       EXTEND(SP, 1);
		       mPUSHn(from);
		       XSRETURN(1);
		   } else {
		       croak("invalid 'by' argument: cannot be zero when from != to");
		   }
	  }
	  // Check for wrong direction / infinite loop
	  if ((from < to && by < 0.0) || (from > to && by > 0.0)) {
		   croak("wrong sign in 'by' argument");
	  }
	  /* * Calculate number of elements. 
		* R uses a small epsilon (like 1e-10) to avoid dropping the last 
		* element due to floating point inaccuracies.
		*/
	  double n_elements_d = (to - from) / by;
	  if (n_elements_d < 0.0) n_elements_d = 0.0;
	  size_t n_elements = (n_elements_d + 1e-10) + 1;
	  // Pre-extend the stack to avoid reallocating inside the loop
	  EXTEND(SP, n_elements);
	  double current = from;
	  for (size_t i = 0; i < n_elements; i++) {
		  mPUSHn(from + i * by);
		  current += by;
	  }
	  XSRETURN(n_elements);
	}

SV* rnorm(...)
	CODE:
	{
	  // Auto-seed the PRNG if the Perl script hasn't done so yet
	  AUTO_SEED_PRNG();

	  if (items % 2 != 0)
		   croak("Usage: rnorm(n => 10, mean => 0, sd => 1) - must be even key/value pairs");
	  // --- Parse named arguments from the flat stack ---
	  size_t n = 0;
	  double mean = 0.0, sd = 1.0;
	  for (unsigned short int i = 0; i < items; i += 2) {
		   const char* restrict key = SvPV_nolen(ST(i));
		   SV* restrict val = ST(i + 1);

		   if      (strEQ(key, "n"))      n    = (unsigned int)SvUV(val);
		   else if (strEQ(key, "mean"))   mean = SvNV(val);
		   else if (strEQ(key, "sd"))     sd   = SvNV(val);
		   else croak("rnorm: unknown argument '%s'", key);
	  }
	  
	  if (sd < 0.0) croak("rnorm: standard deviation must be non-negative");
	  
	  AV *restrict result_av = newAV();
	  if (n > 0) {
		   av_extend(result_av, n - 1);
		   // Generate random normals using the Box-Muller transform
		   for (size_t i = 0; i < n; ) {
		       double u, v, s;
		       do {
		           // Drand01() hooks into Perl's internal PRNG, respecting Perl's srand()
		           u = 2.0 * Drand01() - 1.0;
		           v = 2.0 * Drand01() - 1.0;
		           s = u * u + v * v;
		       } while (s >= 1.0 || s == 0.0);
		       
		       double mul = sqrt(-2.0 * log(s) / s);
		       // Box-Muller generates two independent values per iteration
		       av_store(result_av, i++, newSVnv(mean + sd * u * mul));
		       if (i < n) {
		           av_store(result_av, i++, newSVnv(mean + sd * v * mul));
		       }
		   }
	  }
	  
	  RETVAL = newRV_noinc((SV*)result_av);
	}
	OUTPUT:
	  RETVAL

SV*
aov(data_ref, formula_sv)
	SV* data_ref
	SV* formula_sv
	CODE:
	{
	  HV*restrict data;
	  char *restrict f_str, *restrict lhs, *restrict rhs, *restrict token, *saveptr;
	  char **restrict terms;
	  unsigned int num_terms = 0, row;
	  size_t n;
	  double **restrict X_mat;
	  double *restrict y_vec;
	  double rss_prev;
	  HV*restrict ret_hash;

	  if (!SvROK(data_ref) || SvTYPE(SvRV(data_ref)) != SVt_PVHV)
		   croak("aov: data must be a HashRef");

	  data = (HV*)SvRV(data_ref);
	  f_str = savepv(SvPV_nolen(formula_sv));

	  // --- Formula parsing: lhs ~ rhs ---------------------------------
	  lhs = strtok_r(f_str, "~", &saveptr);
	  rhs = strtok_r(NULL, "~", &saveptr);
	  if (!lhs || !rhs) { Safefree(f_str); croak("aov: invalid formula (missing '~')"); }

	  // Trim whitespace from lhs
	  while (isspace((unsigned char)*lhs)) lhs++;
	  token = lhs + strlen(lhs) - 1;
	  while (token > lhs && isspace((unsigned char)*token)) *token-- = '\0';

	  // Trim whitespace from rhs
	  while (isspace((unsigned char)*rhs)) rhs++;
	  { char *restrict rhs_end = rhs + strlen(rhs) - 1;
		 while (rhs_end > rhs && isspace((unsigned char)*rhs_end)) *rhs_end-- = '\0'; }

	  // --- Row count from first column --------------------------------
	  HE*restrict entry;
	  hv_iterinit(data);
	  if (!(entry = hv_iternext(data))) { Safefree(f_str); croak("aov: empty data"); }
	  SV* first_col = hv_iterval(data, entry);
	  if (!SvROK(first_col) || SvTYPE(SvRV(first_col)) != SVt_PVAV) {
		   Safefree(f_str);
		   croak("aov: data values must be array references (column-oriented HoA)");
	  }
	  n = av_len((AV*)SvRV(first_col)) + 1;

	  // --- Tokenize RHS terms by '+' ----------------------------------
	  terms = (char**)safemalloc(32 * sizeof(char*));
	  token = strtok_r(rhs, "+", &saveptr);
	  while (token && num_terms < 32) {
		   while (isspace((unsigned char)*token)) token++;
		   char*restrict end = token + strlen(token) - 1;
		   while (end > token && isspace((unsigned char)*end)) *end-- = '\0';
		   // Skip intercept override tokens
		   if (strcmp(token, "1") != 0 && strcmp(token, "-1") != 0)
		       terms[num_terms++] = savepv(token);
		   token = strtok_r(NULL, "+", &saveptr);
	  }
	  // p = number of X columns (Intercept + predictors)
	  int p = num_terms + 1;
	  /* --- Build fully symmetric augmented matrix [X'X X'y; y'X y'y] -
		*
		* Layout (mat_size × mat_size):
		*   xtx[0..p-1][0..p-1]  =  X'X
		*   xtx[0..p-1][p]       =  X'y  (last column)
		*   xtx[p][0..p-1]       =  y'X  (last row  — THE FIX)
		*   xtx[p][p]            =  y'y
		*
		* Without the y'X row the sweep operator cannot update xtx[p][p]
		* when pivoting the intercept, so SST_corrected is never computed
		* and every sequential SS is wrong.
		* ---------------------------------------------------------------- */
	  X_mat = (double**)safemalloc(n * sizeof(double*));
	  for (size_t i = 0; i < n; i++) {
		   X_mat[i] = (double*)safemalloc(p * sizeof(double));
	  }
	  y_vec = (double*)safemalloc(n * sizeof(double));

	  size_t valid_n = 0;
		for (row = 0; row < (int)n; row++) {
		   double y = evaluate_term_aov(data, lhs, row);
		   if (isnan(y)) continue; /* skip rows with missing response */

		   X_mat[valid_n][0] = 1.0; /* Intercept */
		   for (unsigned i = 0; i < num_terms; i++) {
		       X_mat[valid_n][i+1] = evaluate_term_aov(data, terms[i], row);
		   }
		   y_vec[valid_n] = y;
		   valid_n++;
	  }
	  ret_hash = newHV();
	// --- Sequential (Type I) SS via Householder QR -----------------
	  apply_householder_aov(X_mat, y_vec, valid_n, p);
	  /* Calculate SST Corrected (Residual after removing just intercept).
		  Because Q is orthogonal, SST is simply the sum of squares of the 
		  transformed y vector, skipping the intercept index (0) */
	  rss_prev = 0.0;
	  for (size_t i = 1; i < valid_n; i++) {
		   rss_prev += y_vec[i] * y_vec[i];
	  }
	  for (unsigned i = 0; i < num_terms; i++) {
		   /* The SS explained by term i is exactly the square of the 
		      transformed y element at index i+1 */
		   double ss_term = y_vec[i + 1] * y_vec[i + 1];
		   
		   rss_prev -= ss_term; /* Update residual sum of squares */
		   if (rss_prev < 0.0) rss_prev = 0.0; /* Float safeguard */
		   
		   HV*restrict term_stats = newHV();
		   hv_stores(term_stats, "Df",     newSViv(1));
		   hv_stores(term_stats, "Sum Sq", newSVnv(ss_term));
		   hv_store(ret_hash, terms[i], strlen(terms[i]),
		            newRV_noinc((SV*)term_stats), 0);
	  }
	  // --- Residuals --------------------------------------------------
	  // Use valid_n (rows with non-NA response) to match R's df.residual
	  int res_df = (int)valid_n - p;
	  double ms_res = (res_df > 0) ? rss_prev / res_df : 0.0;

	  HV*restrict res_stats = newHV();
	  hv_stores(res_stats, "Df",      newSViv(res_df));
	  hv_stores(res_stats, "Sum Sq",  newSVnv(rss_prev));
	  hv_stores(res_stats, "Mean Sq", newSVnv(ms_res));
	  hv_stores(ret_hash, "Residuals", newRV_noinc((SV*)res_stats));
	  // --- F-statistics and p-values ----------------------------------
	  for (unsigned i = 0; i < num_terms; i++) {
		   SV**restrict term_sv = hv_fetch(ret_hash, terms[i], strlen(terms[i]), 0);
		   HV*restrict t_hv = (HV*)SvRV(*term_sv);

		   double ss  = SvNV(*hv_fetch(t_hv, "Sum Sq", 6, 0));
		   double ms  = ss / 1.0; /* df = 1 per continuous predictor term */
		   hv_stores(t_hv, "Mean Sq", newSVnv(ms));

		   if (ms_res > 0.0) {
		       double f_val = ms / ms_res;
		       hv_stores(t_hv, "F value", newSVnv(f_val));
		       // Upper-tail p-value: P(F > f_val) = 1 - pf(f_val, df1, df2)
		       hv_stores(t_hv, "Pr(>F)",
		                 newSVnv(1.0 - pf(f_val, 1.0, (double)res_df)));
		   } else {
		       hv_stores(t_hv, "F value", newSVnv(NAN));
		       hv_stores(t_hv, "Pr(>F)",  newSVnv(NAN));
		   }
	  }

	  // --- Cleanup ----------------------------------------------------
	  for (unsigned i = 0; i < num_terms; i++) Safefree(terms[i]);
	  Safefree(terms);
	  for (size_t i = 0; i < n; i++) Safefree(X_mat[i]);
	  Safefree(X_mat); Safefree(y_vec); Safefree(f_str);

	  RETVAL = newRV_noinc((SV*)ret_hash);
	}
	OUTPUT:
		RETVAL

PROTOTYPES: DISABLE

SV*
fisher_test(data_ref, conf_level = 0.95)
	SV* data_ref
	double conf_level
	PREINIT:
	  size_t a = 0, b = 0, c = 0, d = 0;
	  double p_val, mle_or, ci_low, ci_high;
	  HV*restrict ret_hash;
	  AV*restrict ci_array;
	  HV*restrict est_hash;
	CODE:
	  if (!SvROK(data_ref)) croak("fisher_test requires a reference to an Array or Hash");
	  SV*restrict deref = SvRV(data_ref);
	  /* Fast Path: 2D Array / AoA */
	  if (SvTYPE(deref) == SVt_PVAV) {
		   AV*restrict outer = (AV*)deref;
		   if (av_len(outer) != 1) croak("Outer array must have exactly 2 rows");
		   
		   SV**restrict row1_ptr = av_fetch(outer, 0, 0);
		   SV**restrict row2_ptr = av_fetch(outer, 1, 0);
		   
		   if (row1_ptr && row2_ptr && SvROK(*row1_ptr) && SvROK(*row2_ptr)) {
		       AV*restrict row1 = (AV*)SvRV(*row1_ptr);
		       AV*restrict row2 = (AV*)SvRV(*row2_ptr);
		       
		       a = SvIV(*av_fetch(row1, 0, 0));
		       b = SvIV(*av_fetch(row1, 1, 0));
		       c = SvIV(*av_fetch(row2, 0, 0));
		       d = SvIV(*av_fetch(row2, 1, 0));
		   } else {
		       croak("Invalid 2D Array structure");
		   }
	  } 
//Complex Path: 2D Hash (Because Perl hash order is random, we extract the first 4 integers found in the nested hashes)
	  else if (SvTYPE(deref) == SVt_PVHV) {
		   HV*restrict outer = (HV*)deref;
		   HE*restrict outer_entry;
		   unsigned short int val_count = 0;
		   int vals[4] = {0, 0, 0, 0};
		   
		   hv_iterinit(outer);
		   while ((outer_entry = hv_iternext(outer))) {
		       SV*restrict inner_sv = hv_iterval(outer, outer_entry);
		       if (SvROK(inner_sv) && SvTYPE(SvRV(inner_sv)) == SVt_PVHV) {
		           HV*restrict inner = (HV*)SvRV(inner_sv);
		           HE*restrict inner_entry;
		           hv_iterinit(inner);
		           while ((inner_entry = hv_iternext(inner)) && val_count < 4) {
		               vals[val_count++] = SvIV(hv_iterval(inner, inner_entry));
		           }
		       }
		   }
		   if (val_count != 4) croak("2D Hash must contain exactly 4 values");
		   a = vals[0]; b = vals[1]; c = vals[2]; d = vals[3];
	  } else {
		   croak("Input must be a 2D Array or 2D Hash");
	  }
	  // Perform Calculations
	  p_val = exact_p_value(a, b, c, d);
	  calculate_exact_stats(a, b, c, d, conf_level, &mle_or, &ci_low, &ci_high);
	  // Construct the Return HashRef purely in C
	  ret_hash = newHV();
	  hv_stores(ret_hash, "p_value", newSVnv(p_val));
	  hv_stores(ret_hash, "method", newSVpv("Fisher's Exact Test for Count Data", 0));
	  
	  ci_array = newAV();
	  av_push(ci_array, newSVnv(ci_low));
	  av_push(ci_array, newSVnv(ci_high));
	  hv_stores(ret_hash, "conf_int", newRV_noinc((SV*)ci_array));
	  
	  est_hash = newHV();
	  hv_stores(est_hash, "odds ratio", newSVnv(mle_or));
	  hv_stores(ret_hash, "estimate", newRV_noinc((SV*)est_hash));
	  // Return the HashRef
	  RETVAL = newRV_noinc((SV*)ret_hash);
	OUTPUT:
	  RETVAL

