#!/usr/bin/env perl
use 5.042.2;
no source::encoding;
package Stats::LikeR;
our $VERSION = 0.01;
require XSLoader;
#use DDP {output => 'STDOUT', array_max => 10, show_memsize => 1};
#use Devel::Confess 'color';
use 5.042.2;
no source::encoding;
use warnings FATAL => 'all';
use autodie ':default';
use Exporter 'import';
use Scalar::Util qw(looks_like_number);
use List::Util qw(uniq);
our @EXPORT_OK = qw(aov cor cor_test fisher_test glm hist lm matrix mean median min max p_adjust quantile rbinom rnorm runif scale sd seq shapiro_test t_test var);
our @EXPORT = @EXPORT_OK;
package Stats::LikeR;

require XSLoader;
XSLoader::load('Stats::LikeR', $VERSION);

sub _get_val {
    my ($row_hash, $term) = @_;
    my $val = $row_hash->{$term};
    return (defined $val && looks_like_number($val)) ? $val + 0.0 : undef;
}

sub _build_model_matrix {
    my ($formula, $data) = @_;
    my ($lhs, $rhs) = split /\~/, $formula;
    $lhs =~ s/^\s+|\s+$//g;
    $rhs =~ s/\s//g;
    
    my $has_intercept = ($rhs !~ m/\-1/);
    my @raw_terms = split /\+/, $rhs;
    my @parsed_terms;
    
    # R-style formula expansion: Handle interactions and ignore un-isolated powers
    foreach my $term (@raw_terms) {
        next if $term eq '1' || $term eq '-1';
        
        # Strip polynomial indicators unless wrapped in I()
        if ($term !~ m/^I\(/) {
            $term =~ s/\^\d+$//; 
        }
        
        if ($term =~ m/\*/) {
            my ($left, $right) = split /\*/, $term;
            $left =~ s/\^\d+$// if $left !~ m/^I\(/;
            $right =~ s/\^\d+$// if $right !~ m/^I\(/;
            push @parsed_terms, $left, $right, "$left:$right";
        } else {
            push @parsed_terms, $term;
        }
    }
    @parsed_terms = uniq(@parsed_terms);
    
    # Normalize Data Structure: Handle both HoA (Column-oriented) and HoH (Row-oriented)
    my @rows;
    my @row_names;
    my @keys = keys %$data;
    my $first_val = $data->{$keys[0]};

    if (ref($first_val) eq 'ARRAY') {
        # HoA: outer key = column name, inner value = array of values per row
        my $n = scalar @$first_val;
        for my $i (0 .. $n - 1) {
            my %row;
            for my $k (@keys) { $row{$k} = $data->{$k}->[$i]; }
            push @rows, \%row;
            push @row_names, $i + 1; # R uses 1-based indexing for dataframes
        }
    } elsif (ref($first_val) eq 'HASH') {
        # HoH: two possible orientations:
        #   (a) Column-oriented: outer key = column name, inner key = row/obs name
        #       e.g. { mpg => { 'Mazda RX4' => 21, ... }, hp => { ... } }
        #   (b) Row-oriented:    outer key = row/obs name,  inner key = column name
        #       e.g. { 'Mazda RX4' => { mpg => 21, hp => 110, ... }, ... }
        # Detect by checking whether the LHS response variable is an outer key.
        if (exists $data->{$lhs}) {
            # Column-oriented HoH: pivot to row-wise representation
            my @inner_row_names = sort keys %{ $data->{$lhs} };
            for my $rname (@inner_row_names) {
                my %row;
                for my $k (@keys) { $row{$k} = $data->{$k}{$rname}; }
                push @rows, \%row;
                push @row_names, $rname;
            }
        } else {
            # Row-oriented HoH: outer key is the observation/row name
            for my $k (sort keys %$data) {
                push @rows, $data->{$k};
                push @row_names, $k;
            }
        }
    } else {
        die "Stats::LikeR: Dataset must be a Hash of Arrays or Hash of Hashes.";
    }

    # Dummy Encoding Detection
    my %is_categorical;
    my %levels;
    foreach my $term (@parsed_terms) {
        next if $term =~ m/[:\^]/; 
        foreach my $row (@rows) {
            my $val = $row->{$term};
            if (defined $val) {
                if (!looks_like_number($val)) {
                    $is_categorical{$term} = 1;
                    my @all_levels = sort(uniq(map { $_->{$term} } grep { defined $_->{$term} } @rows));
                    shift @all_levels; # Reference baseline dropped
                    $levels{$term} = \@all_levels;
                }
                last;
            }
        }
    }
    
    my @final_term_names;
    push @final_term_names, 'Intercept' if $has_intercept;
    foreach my $term (@parsed_terms) {
        if ($is_categorical{$term}) {
            push @final_term_names, map { "$term$_" } @{$levels{$term}};
        } else {
            push @final_term_names, $term;
        }
    }
    
    my (@Y, @X_flat, @final_row_names);
    my $idx = 0;
    foreach my $row (@rows) {
        my $rname = $row_names[$idx++];
        my $y_val = _get_val($row, $lhs);
        
        if (defined $y_val) {
            my @x_row;
            push @x_row, 1.0 if $has_intercept;
            my $row_ok = 1;
            
            foreach my $term (@parsed_terms) {
                if ($is_categorical{$term}) {
                    my $str_val = $row->{$term};
                    if (!defined $str_val) { $row_ok = 0; last; }
                    foreach my $lvl (@{$levels{$term}}) {
                        push @x_row, ($str_val eq $lvl) ? 1.0 : 0.0;
                    }
                } elsif ($term =~ m/^(.*?):(.*?)$/) {
                    my $val1 = _get_val($row, $1);
                    my $val2 = _get_val($row, $2);
                    if (!defined $val1 || !defined $val2) { $row_ok = 0; last; }
                    push @x_row, $val1 * $val2;
                } elsif ($term =~ m/^I\((.*?)\^(\d+)\)$/) {
                    my $val = _get_val($row, $1);
                    if (!defined $val) { $row_ok = 0; last; }
                    push @x_row, $val ** $2;
                } else {
                    my $val = _get_val($row, $term);
                    if (!defined $val) { $row_ok = 0; last; }
                    push @x_row, $val;
                }
            }
            if ($row_ok) {
                push @Y, $y_val;
                push @X_flat, @x_row;
                push @final_row_names, $rname;
            }
        }
    }
    
    die "0 degrees of freedom" unless @Y > @final_term_names;
    return (\@Y, \@X_flat, \@final_term_names, \@final_row_names);
}

sub lm {
    my %args = @_;
    die "formula is required" unless defined $args{formula};
    die "data must be a hash reference" unless ref($args{data}) eq 'HASH';
    my ($Y, $X_flat, $term_names, $row_names) = _build_model_matrix($args{formula}, $args{data});
    return _glm_fit($Y, $X_flat, $term_names, $row_names, 'gaussian');
}

sub glm {
    my %args = @_;
    die "formula is required" unless defined $args{formula};
    die "data must be a hash reference" unless ref($args{data}) eq 'HASH';
    my $family = $args{family} || 'gaussian';
    my ($Y, $X_flat, $term_names, $row_names) = _build_model_matrix($args{formula}, $args{data});
    return _glm_fit($Y, $X_flat, $term_names, $row_names, $family);
}

1;
#sub mean {
#	my @n = map { ref($_) eq 'ARRAY' ? @$_ : $_ } @_;
#	my $current_sub = ( split( /::/, ( caller(0) )[3] ) )[-1];
#	die "$current_sub needs >= 1 element in the array" if scalar @n < 1;
#	return sum(@n) / scalar @n;
#}

#sub stdev {
#	my @n = map { ref($_) eq 'ARRAY' ? @$_ : $_ } @_;
#	my $current_sub = ( split( /::/, ( caller(0) )[3] ) )[-1];
#	die "$current_sub needs >= 2 elements in the array" if scalar @n < 2;
#	my $mean = sum(@n) / scalar @n;
#	my $standard_deviation = 0;
#	foreach my $element (@n) {
#		$standard_deviation += ($element-$mean)**2;
#	}
#	return sqrt($standard_deviation/((scalar @n)-1));
#}

#sub population_variance { # sample variance
#	my @n = map { ref($_) eq 'ARRAY' ? @$_ : $_ } @_;
#	my $current_sub = ( split( /::/, ( caller(0) )[3] ) )[-1];
#	die "$current_sub needs >= 1 elements in the array" if scalar @n < 1;
#	my $mean = sum(@n) / scalar @n;
#	my $var = 0;
#	foreach my $element (@n) {
#		$var += ($element-$mean)**2;
#	}
#	return $var / scalar @n;
#}

#sub sample_variance { # sample variance
#	my @n = map { ref($_) eq 'ARRAY' ? @$_ : $_ } @_;
#	my $current_sub = ( split( /::/, ( caller(0) )[3] ) )[-1];
#	die "$current_sub needs >= 1 elements in the array" if scalar @n < 1;
#	my $mean = sum(@n) / scalar @n;
#	my $var = 0;
#	foreach my $element (@n) {
#		$var += ($element-$mean)**2;
#	}
#	return $var / (scalar @n - 1);
#}

#sub pvalue ($array1, $array2) {
#	return 1.0 if scalar @$array1 <= 1;
#	return 1.0 if scalar @$array2 <= 1;
#	my $mean1 = sum(@{ $array1 });
#	my $mean2 = sum(@{ $array2 });
#	return 1.0 if ($mean1 == $mean2);
#	$mean2 /= scalar @$array2;
#	$mean1 /= scalar @$array1;
#	my ($variance1, $variance2) = (0, 0);
#	foreach my $x (@$array1) {
#	$variance1 += ($x-$mean1)*($x-$mean1);
#	}
#	foreach my $x (@$array2) {
#	$variance2 += ($x-$mean2)*($x-$mean2);
#	}
#	if (($variance1 == 0.0) && ($variance2 == 0.0)) {
#	return 1.0;
#	}
#	$variance1 = $variance1/(scalar @$array1-1);
#	$variance2 = $variance2/(scalar @$array2-1);
#	my $array1_size = scalar @$array1;
#	my $array2_size = scalar @$array2;
#	my $WELCH_T_STATISTIC = ($mean1-$mean2)/sqrt($variance1/$array1_size+$variance2/$array2_size);
#	my $DEGREES_OF_FREEDOM = (($variance1/$array1_size+$variance2/(scalar @$array2))**2)
#	/
#	(
#	($variance1*$variance1)/($array1_size*$array1_size*($array1_size-1))+
#	($variance2*$variance2)/($array2_size*$array2_size*($array2_size-1))
#	);
#	my $A = $DEGREES_OF_FREEDOM/2;
#	my $value = $DEGREES_OF_FREEDOM/($WELCH_T_STATISTIC*$WELCH_T_STATISTIC+$DEGREES_OF_FREEDOM);
##from here, translation of John Burkhardt's C
#	my $beta = lgamma($A)+0.57236494292470009-lgamma($A+0.5);
#	my $acu = 10**(-15);
#	my($ai,$cx,$indx,$ns,$pp,$psq,$qq,$rx,$temp,$term,$xx);
## Check the input arguments.
#	return $value if $A <= 0.0;# || $q <= 0.0;
#	return $value if $value < 0.0 || 1.0 < $value;
## Special cases
#	return $value if $value == 0.0 || $value == 1.0;
#	$psq = $A + 0.5;
#	$cx = 1.0 - $value;
#	if ($A < $psq * $value) {
#		($xx, $cx, $pp, $qq, $indx) = ($cx, $value, 0.5, $A, 1);
#	} else {
#		($xx, $pp, $qq, $indx) = ($value, $A, 0.5, 0);
#	}
#	$term = 1.0;
#	$ai = 1.0;
#	$value = 1.0;
#	$ns = int($qq + $cx * $psq);
##Soper reduction formula.
#	$rx = $xx / $cx;
#	$temp = $qq - $ai;
#	$rx = $xx if $ns == 0;
#	while (1) {
#		$term = $term * $temp * $rx / ( $pp + $ai );
#		$value = $value + $term;
#		$temp = abs ($term);
#		if ($temp <= $acu && $temp <= $acu * $value) {
#	   	$value = $value * exp ($pp * log($xx)
#	                          + ($qq - 1.0) * log($cx) - $beta) / $pp;
#	   	$value = 1.0 - $value if $indx;
#	   	last;
#		}
#	 	$ai = $ai + 1.0;
#		$ns = $ns - 1;
#		if (0 <= $ns) {
#			$temp = $qq - $ai;
#			$rx = $xx if $ns == 0;
#		} else {
#			$temp = $psq;
#			$psq = $psq + 1.0;
#		}
#	}
#	return $value;
#}

#sub paired_pvalue ($array1, $array2) {
#	return 1.0 if scalar @$array1 <= 1;
#	return 1.0 if scalar @$array2 <= 1;
#	my $array_size = scalar @$array1;
#	if ($array_size != scalar @$array2) {
#		die 'arrays have different sizes, cannot calculate paired p-value.';
#	}
#	my ($sd, $xd) = (0,0);
#	foreach my $x (0..$array_size-1) {
#		$xd += (@$array2[$x] - @$array1[$x]);
#	}
#	return 1.0 if $xd == 0;
#	$xd /= $array_size;
#	foreach my $x (0..$array_size-1) {
#		$sd += ($xd - (@$array2[$x] - @$array1[$x]))**2;
#	}
#	$sd = sqrt($sd / ($array_size - 1));
#	my $t = $xd / ($sd / sqrt($array_size));
#	my $DEGREES_OF_FREEDOM = $array_size - 1;#http://oak.ucc.nau.edu/rh232/courses/EPS525/Handouts/Understanding%20the%20Dependent%20t%20Test.pdf
#	my $A = $DEGREES_OF_FREEDOM/2;
#	my $value = $DEGREES_OF_FREEDOM/($t*$t+$DEGREES_OF_FREEDOM);
##from here, translation of John Burkhardt's C
#	my $beta = lgamma($A)+0.57236494292470009-lgamma($A+0.5);
#	my $acu = 10**(-15);
#	my($ai,$cx,$indx,$ns,$pp,$psq,$qq,$rx,$temp,$term,$xx);
## Check the input arguments.
#	return $value if $A <= 0.0;# || $q <= 0.0;
#	return $value if $value < 0.0 || 1.0 < $value;
## Special cases
#	return $value if $value == 0.0 || $value == 1.0;
#	$psq = $A + 0.5;
#	$cx = 1.0 - $value;
#	if ($A < $psq * $value) {
#		($xx, $cx, $pp, $qq, $indx) = ($cx, $value, 0.5, $A, 1);
#	} else {
#		($xx, $cx, $pp, $qq, $indx) = ($value, $cx, $A, 0.5, 0);
#	}
#	$term = 1.0;
#	$ai = 1.0;
#	$value = 1.0;
#	$ns = int($qq + $cx * $psq);
##Soper reduction formula.
#	$rx = $xx / $cx;
#	$temp = $qq - $ai;
#	$rx = $xx if $ns == 0;
#	while (1) {
#		$term = $term * $temp * $rx / ( $pp + $ai );
#		$value = $value + $term;
#		$temp = abs ($term);
#		if ($temp <= $acu && $temp <= $acu * $value) {
#			$value = $value * exp ($pp * log($xx)
#				                   + ($qq - 1.0) * log($cx) - $beta) / $pp;
#			$value = 1.0 - $value if $indx;
#			last;
#		}
#		$ai = $ai + 1.0;
#		$ns = $ns - 1;
#		if (0 <= $ns) {
#			$temp = $qq - $ai;
#			$rx = $xx if $ns == 0;
#		} else {
#			$temp = $psq;
#			$psq = $psq + 1.0;
#		}
#	}
#	$value;
#}

1;
